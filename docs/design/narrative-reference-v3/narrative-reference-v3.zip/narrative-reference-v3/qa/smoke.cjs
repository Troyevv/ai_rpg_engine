/* DOM smoke checks for the standalone reference prototype. No browser/layout claims.
   Harness shims emulate browser form APIs missing from linkedom. Product
   sources are loaded unchanged in their actual assembly order. */
'use strict';
const {parseHTML}=require('linkedom');
const vm=require('node:vm');
const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const base=path.resolve(__dirname,'../src');
const files=['ui-shell.js','phone.js','main.js','management.js','shell-features.js'];

function harness({width=1440}={}){
  const markup=fs.readFileSync(path.join(base,'base.html'),'utf8').replace('<!-- PHONE_MARKUP -->',fs.readFileSync(path.join(base,'phone-markup.html'),'utf8'));
  const {window:win,document:doc}=parseHTML('<!doctype html><html><head></head><body>'+markup+'</body></html>');
  const q=s=>doc.querySelector(s),qa=s=>Array.from(doc.querySelectorAll(s));
  const app=q('#nr-app');
  app.getBoundingClientRect=()=>({width,height:900,left:0,top:0,right:width,bottom:900,x:0,y:0});
  Object.defineProperty(app,'clientWidth',{get:()=>width,configurable:true});
  // Emulate the known closed-drawer visibility for focus routing only.
  // This is not a layout engine or evidence that mobile CSS renders correctly.
  const closedMobileSidebar=el=>width<=680&&!!el.closest('.nr-sidebar')&&!app.classList.contains('nr-navopen');
  let active=doc.body,clock=0,nextFrame=0,nextTimer=0;
  const frames=new Map(),timers=new Map();
  const HTMLElement=win.HTMLElement.prototype;
  Object.defineProperty(doc,'activeElement',{get:()=>active});
  Object.defineProperty(HTMLElement,'inert',{get(){return this.hasAttribute('inert');},set(v){this.toggleAttribute('inert',!!v);},configurable:true});
  Object.defineProperty(HTMLElement,'tabIndex',{get(){return this.hasAttribute('tabindex')?Number(this.getAttribute('tabindex')):(/^(BUTTON|INPUT|TEXTAREA|SELECT|A)$/.test(this.tagName)?0:-1);},set(v){this.setAttribute('tabindex',String(v));},configurable:true});
  Object.defineProperty(HTMLElement,'maxLength',{get(){return this.hasAttribute('maxlength')?Number(this.getAttribute('maxlength')):-1;},configurable:true});
  HTMLElement.focus=function(){if(!this.disabled&&!this.closest('[inert],[hidden]')&&!closedMobileSidebar(this))active=this;};
  HTMLElement.getClientRects=function(){return this.closest('[hidden],[inert]')||closedMobileSidebar(this)?[]:[{width:1,height:1}];};
  HTMLElement.scrollTo=function(opts){this.scrollTop=opts.top;};
  Object.defineProperty(win.HTMLInputElement.prototype,'checked',{get(){return this.hasAttribute('checked');},set(v){this.toggleAttribute('checked',!!v);},configurable:true});
  Object.defineProperties(win.HTMLSelectElement.prototype,{
    value:{configurable:true,get(){const chosen=this.querySelector('option[selected]')||(!this.__qaNoSelection?this.querySelector('option'):null);return chosen?(chosen.getAttribute('value')??chosen.textContent):'';},set(v){let found=false;this.querySelectorAll('option').forEach(o=>{const selected=(o.getAttribute('value')??o.textContent)===String(v);o.toggleAttribute('selected',selected);found=found||selected;});this.__qaNoSelection=!found;}},
    selectedOptions:{configurable:true,get(){return Array.from(this.querySelectorAll('option')).filter(o=>o.hasAttribute('selected')||(!this.querySelector('option[selected]')&&!this.__qaNoSelection&&o===this.querySelector('option')));}},
    selectedIndex:{configurable:true,get(){return Array.from(this.querySelectorAll('option')).indexOf(this.selectedOptions[0]);},set(v){const option=this.querySelectorAll('option')[v];this.value=option?(option.getAttribute('value')??option.textContent):'';}}
  });
  Object.defineProperty(HTMLElement,'elements',{configurable:true,get(){if(this.tagName!=='FORM')return undefined;const nodes=Array.from(this.querySelectorAll('input,textarea,select,button'));for(const el of nodes){const name=el.getAttribute('name');if(name)nodes[name]=el;}nodes.namedItem=name=>nodes[name]||null;return nodes;}});
  function valid(el){
    if(el.disabled)return true;
    if(el.hasAttribute('required')&&!String(el.value??'').trim())return false;
    if(el.type==='number'&&String(el.value??'').trim()){
      const n=Number(el.value);if(!Number.isFinite(n))return false;
      if(el.hasAttribute('min')&&n<Number(el.getAttribute('min')))return false;
      if(el.hasAttribute('max')&&n>Number(el.getAttribute('max')))return false;
    }
    return true;
  }
  Object.defineProperty(HTMLElement,'validity',{configurable:true,get(){return {valid:valid(this)};}});
  HTMLElement.checkValidity=HTMLElement.reportValidity=function(){return this.tagName==='FORM'?Array.from(this.querySelectorAll('input,textarea,select')).every(valid):valid(this);};
  HTMLElement.requestSubmit=function(){if(this.tagName==='FORM'&&this.reportValidity())this.dispatchEvent(new win.Event('submit',{bubbles:true,cancelable:true}));};
  HTMLElement.click=function(){if(!this.disabled&&!this.closest('[hidden],[inert]')){this.focus();this.dispatchEvent(new win.Event('click',{bubbles:true,cancelable:true}));}};
  class BrowserFormData{
    constructor(form){this.values=[];if(form)for(const el of form.elements){if(el.disabled||!el.name||/^(submit|button|reset)$/.test(el.type))continue;if(/^(checkbox|radio)$/.test(el.type)&&!el.checked)continue;this.append(el.name,el.value);}}
    append(k,v){this.values.push([k,v]);}get(k){return this.values.find(x=>x[0]===k)?.[1]??null;}getAll(k){return this.values.filter(x=>x[0]===k).map(x=>x[1]);}entries(){return this.values[Symbol.iterator]();}[Symbol.iterator](){return this.entries();}
  }
  const setT=(f,ms,repeat=false)=>{const id=++nextTimer;timers.set(id,{f,ms,repeat});return id;},clearT=id=>timers.delete(id);
  const raf=f=>{const id=++nextFrame;frames.set(id,f);return id;},caf=id=>frames.delete(id);
  win.matchMedia=query=>({media:query,matches:false,addEventListener(){},removeEventListener(){},addListener(){},removeListener(){}});
  win.getComputedStyle=el=>({display:el.hidden?'none':(el.style.display||'block'),visibility:closedMobileSidebar(el)?'hidden':el.style.visibility||'visible'});
  win.setTimeout=setT;win.clearTimeout=clearT;win.setInterval=(f,ms)=>setT(f,ms,true);win.clearInterval=clearT;win.requestAnimationFrame=raf;win.cancelAnimationFrame=caf;
  win.lucide={createIcons(){}};
  const context=vm.createContext({window:win,document:doc,console,requestAnimationFrame:raf,cancelAnimationFrame:caf,setTimeout:setT,clearTimeout:clearT,setInterval:win.setInterval,clearInterval:clearT,CustomEvent:win.CustomEvent,Event:win.Event,FormData:BrowserFormData,TextDecoder,Date,Map,Set,Intl});
  for(const file of files)vm.runInContext(fs.readFileSync(path.join(base,file),'utf8'),context,{filename:file,timeout:5000});
  const root=q('#nr-app'),ui=root.__nrUI,input=q('#nr-action'),feed=q('.nr-feed');
  win.installNarrativeManagement(root,ui);win.installNarrativeShellFeatures(root,ui);
  Object.defineProperties(feed,{clientHeight:{value:480},scrollHeight:{get:()=>1000+q('[data-turns]').textContent.length}});feed.scrollTop=0;
  const resolve=value=>{const el=typeof value==='string'?q(value):value;assert.ok(el,'Missing element: '+value);return el;};
  function click(value){const el=resolve(value);assert.ok(!el.disabled,'Disabled click: '+value);assert.ok(!el.closest('[hidden],[inert]'),'Hidden or inert click: '+value);el.click();}
  function type(value,text){const el=resolve(value);el.value=text;el.dispatchEvent(new win.Event('input',{bubbles:true}));}
  function change(value,text){const el=resolve(value);el.value=text;el.dispatchEvent(new win.Event('change',{bubbles:true}));}
  function key(value,key,extras={}){const el=resolve(value),e=new win.Event('keydown',{bubbles:true,cancelable:true});e.key=key;Object.assign(e,extras);el.dispatchEvent(e);return e;}
  function submit(value){resolve(value).requestSubmit();}
  function runFrames(){for(let n=0;frames.size&&n<600;n++){clock+=50;const pending=Array.from(frames.values());frames.clear();pending.forEach(fn=>fn(clock));}assert.equal(frames.size,0,'Animation did not terminate');}
  function runTimers(){const pending=Array.from(timers);for(const [id,timer]of pending){if(!timer.repeat)timers.delete(id);timer.f();}}
  function chooseSave(world,save){click('.nr-worldpicker');click('[data-sf-action="select-world"][data-id="'+world+'"]');click('[data-sf-action="continue"][data-id="'+save+'"]');}
  return {q,qa,doc,win,root,ui,input,feed,click,type,change,key,submit,runFrames,runTimers,chooseSave};
}

const results=[];
function test(name,fn,options){
  try{fn(harness(options));results.push({name,passed:true});console.log('PASS '+name);}
  catch(error){results.push({name,passed:false,error:error.stack});console.error('FAIL '+name+'\n'+error.stack);}
}

test('Six semantic cards without numbers; initial disclosure full',({q,qa})=>{
  assert.equal(q('[data-choices-grid]').querySelectorAll('[data-choice]').length,6);assert.equal(qa('.nr-choicenumber').length,0);assert.equal(qa('.nr-choice-speech').length,5);
  assert.equal(q('[data-choice="0"] .nr-choice-mark').dataset.icon,'message-circle');assert.equal(q('[data-choice="3"] .nr-choice-mark').dataset.icon,'arrow-up-right');
  assert.equal(q('.nr-choices').dataset.level,'2');assert.equal(q('[data-choice-level]').textContent,'Полностью');assert.equal(q('.nr-send').disabled,true);
});
test('Selection is explicit; ordinary manual input always clears it',({q,input,click,type})=>{
  click('[data-choice="0"]');assert.equal(q('[data-choice="0"]').getAttribute('aria-pressed'),'true');assert.equal(q('[data-choice="0"] .nr-choice-mark').dataset.icon,'check');
  type(input,input.value);assert.equal(q('[data-choice="0"]').getAttribute('aria-pressed'),'false');assert.equal(q('[data-choice="0"] .nr-choice-mark').dataset.icon,'message-circle');
});
test('Repeated conflict dialogs cancel, append once and replace safely',({q,input,click,type,ui})=>{
  type(input,'Мой исходный черновик');click('[data-choice="1"]');assert.equal(input.value,'Мой исходный черновик');assert.ok(ui.isModalOpen());
  click('[data-choice-draft="cancel"]');assert.equal(input.value,'Мой исходный черновик');click('[data-choice="1"]');const proposal=q('[data-choice-preview]').textContent;
  click('[data-choice-draft="add"]');assert.equal(input.value,'Мой исходный черновик\n'+proposal);assert.equal(q('[data-choice="1"]').getAttribute('aria-pressed'),'true');
  click('[data-choice="3"]');const replace=q('[data-choice-preview]').textContent;assert.notEqual(input.value,replace);click('[data-choice-draft="replace"]');assert.equal(input.value,replace);
});
test('Three disclosure levels, labels and inert follow 2→0→1→2',({q,click})=>{
  for(const [level,label]of [['0','Свёрнуто'],['1','Компактно'],['2','Полностью']]){click('[data-toggle-choices]');assert.equal(q('.nr-choices').dataset.level,level);assert.equal(q('[data-choice-level]').textContent,label);assert.equal(q('#nr-choices-body').inert,level==='0');}
});
test('Number shortcuts removed; Enter is multiline; Ctrl+Enter sends once and restores compact disclosure',({q,qa,input,click,key,runFrames})=>{
  click('[data-choice="3"]');const value=input.value;key(q('[data-toggle-choices]'),'2');assert.equal(input.value,value);const before=qa('[data-turns] .nr-userturn').length;
  assert.equal(key(input,'Enter').defaultPrevented,false);assert.equal(qa('[data-turns] .nr-userturn').length,before);click('[data-toggle-choices]');click('[data-toggle-choices]');
  assert.equal(key(input,'Enter',{ctrlKey:true}).defaultPrevented,true);assert.equal(qa('[data-turns] .nr-userturn').length,before+1);assert.equal(q('.nr-choices').hidden,true);
  key(input,'Enter',{ctrlKey:true});assert.equal(qa('[data-turns] .nr-userturn').length,before+1);runFrames();assert.equal(q('.nr-choices').hidden,false);assert.equal(q('.nr-choices').dataset.level,'1');
});
test('Stopped stream restores collapsed disclosure and editable composer',({q,input,click,type,submit})=>{
  click('[data-toggle-choices]');type(input,'Подождём');submit('[data-main-form]');assert.equal(q('.nr-choices').hidden,true);click('[data-stop]');assert.equal(q('.nr-choices').hidden,false);assert.equal(q('.nr-choices').dataset.level,'0');assert.equal(q('#nr-choices-body').inert,true);assert.equal(input.readOnly,false);
});
test('Management has four functional tabs across repeated openings; camera journal remains separate',({q,qa,click})=>{
  click('.nr-managemententry');assert.equal(qa('[data-gm-tab]').length,4);
  for(const tab of ['characters','chronology','settings','time','characters','chronology']){click('[data-gm-tab="'+tab+'"]');assert.equal(q('[role="tab"][aria-selected="true"]').dataset.gmTab,tab);assert.equal(q('#gm-active-panel').getAttribute('aria-labelledby'),'gm-tab-'+tab);}
  click('[data-close-modal]');click('.nr-camerabutton');click('[data-gm-tab="journal"]');assert.ok(q('[data-gm-journal]'));assert.match(q('#nr-modal-title').textContent,/Камера/);click('[data-gm-tab="characters"]');assert.ok(q('[data-gm-observe="Соня"]'));
});
test('World and save switches restore distinct drafts and disclosure state',({q,input,ui,click,type,chooseSave})=>{
  type(input,'Черновик первого прохождения');click('[data-toggle-choices]');click('[data-toggle-choices]');
  chooseSave('santa','santa-evening');assert.equal(ui.state.saveId,'santa-evening');assert.equal(input.value,'');type(input,'Черновик другого вечера');
  chooseSave('birch','birch-main');assert.equal(ui.state.worldId,'birch');assert.equal(ui.state.actor,'Алексей');assert.equal(input.value,'');assert.equal(q('[data-current-location]').textContent,'Кафе у вокзала');type(input,'Черновик Берёзовска');
  chooseSave('santa','santa-main');assert.equal(input.value,'Черновик первого прохождения');assert.equal(q('.nr-choices').dataset.level,'1');assert.equal(ui.state.actor,'Илья');
  chooseSave('santa','santa-evening');assert.equal(input.value,'Черновик другого вечера');chooseSave('birch','birch-main');assert.equal(input.value,'Черновик Берёзовска');
});
test('RP-chat draft and messages stay independent and survive returning to Narrative',({q,qa,input,click,type,key,ui})=>{
  type(input,'Моё действие в Narrative');const before=q('[data-turns]').innerHTML,minutes=ui.state.minutes;
  click('.nr-rpentry');click('[data-sf-action="open-chat"]');type('[data-sf-chat-form] textarea','Черновик в RP');click('[data-sf-action="narrative"]');assert.equal(input.value,'Моё действие в Narrative');assert.equal(q('[data-turns]').innerHTML,before);
  click('.nr-rpentry');assert.equal(q('[data-sf-chat-form] textarea').value,'Черновик в RP');const count=qa('.sf-chat-message').length;type('[data-sf-chat-form] textarea','<img src=x onerror=alert(1)>');key('[data-sf-chat-form] textarea','Enter',{metaKey:true});
  assert.equal(qa('.sf-chat-message').length,count+2);assert.equal(qa('.sf-chat-message img').length,0);assert.ok(q('.sf-chat-messages').textContent.includes('<img src=x'));click('[data-sf-action="narrative"]');assert.equal(ui.state.minutes,minutes);assert.equal(input.value,'Моё действие в Narrative');assert.equal(q('[data-turns]').innerHTML,before);
});
test('Camera observation does not take control or advance time; temporary control can return to hero',({q,ui,click})=>{
  const minutes=ui.state.minutes;click('.nr-camerabutton');click('[data-gm-observe="Соня"]');assert.equal(ui.state.observer,true);assert.equal(ui.state.actor,null);assert.equal(ui.state.observedActor,'Соня');assert.equal(ui.state.minutes,minutes);assert.equal(q('[data-observer-bar]').hidden,false);
  click('.nr-camerabutton');click('[data-gm-control="Тимур"]');assert.equal(ui.state.observer,false);assert.equal(ui.state.actor,'Тимур');assert.equal(ui.state.protagonist,'Илья');assert.equal(ui.state.minutes,minutes);assert.equal(q('[data-return-bar]').hidden,false);
  click('[data-return-bar] [data-return-hero]');assert.equal(ui.state.actor,'Илья');assert.equal(q('[data-return-bar]').hidden,true);
});
test('Top actor selector updates actual control and composer identity',({q,ui,change})=>{
  change('#nr-actor','Катя');assert.equal(ui.state.actor,'Катя');assert.equal(q('[data-writing-actor]').textContent,'Катя Соколова');assert.equal(q('#nr-actor').value,'Катя');
});
test('Time skip preview has no side effects; confirmation advances precisely one hour',({q,ui,click,submit,runFrames})=>{
  const minutes=ui.state.minutes;click('.nr-managemententry');click('[data-gm-open="time-skip"]');click('[data-gm-preset="60"]');assert.equal(ui.state.minutes,minutes);assert.equal(q('[data-gm-target-time]').textContent,'21:08');
  submit('[data-gm-skip-form]');assert.equal(ui.isModalOpen(),false);assert.equal(ui.state.minutes,minutes+60);assert.equal(q('[data-world-time]').textContent,'21:08');runFrames();assert.equal(q('.nr-choices').hidden,false);
});
test('Calendar browsing never mutates world time',({q,ui,click})=>{
  const minutes=ui.state.minutes,day=ui.state.dayOffset;click('.nr-datetime');click('[data-gm-month-step="1"]');click('[data-gm-calendar-day]');assert.equal(ui.state.minutes,minutes);assert.equal(ui.state.dayOffset,day);assert.ok(q('.gm-calendar-detail'));
});
test('Phone opened from profile preserves narrative draft and restores launcher focus',({q,input,doc,click,type})=>{
  type(input,'Несохранённая реплика');click('.nr-person[data-profile="Соня"]');click('.nr-profileaction');assert.equal(q('[data-sheet]').inert,true);assert.equal(q('.ph-device').inert,false);click('[data-ph-close]');assert.equal(input.value,'Несохранённая реплика');assert.equal(doc.activeElement,q('.nr-phonebutton'));
});
test('Phone message draft survives campaign round trip',({q,click,type,chooseSave})=>{
  click('.nr-phonebutton');click('[data-ph-thread="sonya"]');type('[data-ph-input]','Отложенное сообщение');click('[data-ph-close]');chooseSave('birch','birch-main');chooseSave('santa','santa-main');click('.nr-phonebutton');assert.equal(q('[data-ph-input]').value,'Отложенное сообщение');
});
test('Regenerated responses retain real previous and next variants',({q,click,runFrames})=>{
  const old=q('[data-turns] .nr-turn:last-child .nr-prose').innerHTML;click(q('[data-turns] .nr-turn:last-child [data-regenerate]'));runFrames();const next=q('[data-turns] .nr-turn:last-child .nr-prose').innerHTML;assert.notEqual(old,next);
  click(q('[data-turns] .nr-turn:last-child [data-variant-prev]'));assert.equal(q('[data-turns] .nr-turn:last-child .nr-prose').innerHTML,old);click(q('[data-turns] .nr-turn:last-child [data-variant-next]'));assert.equal(q('[data-turns] .nr-turn:last-child .nr-prose').innerHTML,next);
});
test('Undo is confirmed; cancellation is inert; confirmation restores time and action draft',({q,input,ui,click,type,submit,runFrames})=>{
  const before=q('[data-turns]').innerHTML,minutes=ui.state.minutes;type(input,'Мёрфи, какой приговор?');submit('[data-main-form]');runFrames();const after=q('[data-turns]').innerHTML;
  click('[data-request-undo]');assert.equal(q('[data-turns]').innerHTML,after);click('[data-cancel-undo]');assert.equal(q('[data-turns]').innerHTML,after);
  click('[data-request-undo]');click('[data-confirm-undo]');assert.equal(q('[data-turns]').innerHTML,before);assert.equal(input.value,'Мёрфи, какой приговор?');assert.equal(ui.state.minutes,minutes);
});
test('Modal focus trap and inert background are released on Escape',({q,doc,click,key,ui})=>{
  const opener=q('.nr-managemententry');click(opener);assert.equal(q('.nr-feed').inert,true);assert.equal(q('.nr-sidebar').inert,true);assert.equal(doc.activeElement,q('[data-close-modal]'));
  key(q('[data-close-modal]'),'Tab',{shiftKey:true});assert.ok(q('.nr-modal').contains(doc.activeElement));key(doc.activeElement,'Escape');assert.equal(ui.isModalOpen(),false);assert.equal(q('.nr-feed').inert,false);assert.equal(q('.nr-sidebar').inert,false);assert.equal(doc.activeElement,opener);
});

test('Mobile sidebar locks the game, closes on Escape and restores the visible launcher',({q,root,doc,click,key})=>{
  click('[data-toggle-nav]');assert.equal(root.classList.contains('nr-navopen'),true);assert.equal(q('.nr-stage').inert,true);assert.equal(q('.nr-navbackdrop').hidden,false);assert.equal(doc.activeElement,q('.nr-sidebar button'));
  key(doc.activeElement,'Tab',{shiftKey:true});assert.equal(doc.activeElement,q('.nr-sidebar button:last-child'));key(doc.activeElement,'Tab');assert.equal(doc.activeElement,q('.nr-sidebar button'));
  key(doc.activeElement,'Escape');assert.equal(root.classList.contains('nr-navopen'),false);assert.equal(q('.nr-stage').inert,false);assert.equal(q('.nr-navbackdrop').hidden,true);assert.equal(doc.activeElement,q('[data-toggle-nav]'));
},{width:390});
test('Mobile sidebar can open settings and return focus to visible navigation',({q,root,ui,doc,click})=>{
  click('[data-toggle-nav]');click('.nr-sidebar [data-ui="settings"]');assert.equal(root.classList.contains('nr-navopen'),false);assert.equal(q('.nr-stage').inert,false);assert.equal(ui.isModalOpen(),true);assert.equal(q('.nr-sidebar').inert,true);assert.equal(q('.nr-feed').inert,true);
  click('[data-close-modal]');assert.equal(q('.nr-stage').inert,false);assert.equal(q('.nr-sidebar').inert,false);assert.equal(q('.nr-feed').inert,false);assert.equal(doc.activeElement,q('[data-toggle-nav]'));click('.nr-worldpicker');assert.ok(q('[data-sf-action="select-world"]'));
},{width:390});
test('Mobile actions open the camera, appearance, and a background turn through existing routes',({q,ui,click,runFrames})=>{
  click('.nr-mobilemore');assert.equal(q('.nr-modal').dataset.kind,'menu');assert.ok(q('[data-mobile-background]'));click('.nr-mobile-actions [data-ui="camera"]');assert.ok(q('[data-gm-observe="Соня"]'));click('[data-close-modal]');
  click('.nr-mobilemore');click('.nr-mobile-actions [data-ui="settings"][data-section="appearance"]');assert.ok(q('[data-pref="font"]'));click('[data-close-modal]');
  const minutes=ui.state.minutes;click('.nr-mobilemore');click('[data-mobile-background]');assert.equal(ui.isModalOpen(),false);assert.equal(ui.state.observer,true);assert.equal(ui.state.actor,null);assert.equal(ui.state.minutes,minutes+1);runFrames();assert.equal(q('.nr-choices').hidden,false);
},{width:390});
test('Mobile phone locks only the background and releases it on closing',({q,input,doc,click,type,key})=>{
  type(input,'Сохраняемый черновик');click('.nr-phonebutton');assert.equal(q('.ph-device').getAttribute('aria-modal'),'true');assert.equal(q('.nr-feed').inert,true);assert.equal(q('.nr-composerarea').inert,true);assert.equal(q('.nr-sidebar').inert,true);assert.equal(q('.ph-device').inert,false);
  key(q('[data-ph-close]'),'Tab',{shiftKey:true});assert.ok(q('.ph-device').contains(doc.activeElement));click('[data-ph-close]');assert.equal(input.value,'Сохраняемый черновик');assert.equal(q('.nr-feed').inert,false);assert.equal(q('.nr-composerarea').inert,false);assert.equal(q('.nr-sidebar').inert,false);assert.equal(doc.activeElement,q('.nr-phonebutton'));
},{width:390});
test('Textual phone calls stay inside the phone and preserve narrative choices and draft',({q,qa,input,click,type,runTimers,submit})=>{
  type(input,'Действие за столом');const narrative=q('[data-turns]').innerHTML;click('.nr-phonebutton');click('[data-ph-thread="sonya"]');click('[data-ph-call="sonya"]');assert.ok(q('.ph-call-connecting'));runTimers();assert.ok(q('[data-ph-call-input]'));assert.ok(q('[data-ph-call-log]').textContent.includes('В трубке'));
  const count=qa('.ph-call-message').length;type('[data-ph-call-input]','<img src=x onerror=alert(1)>');submit('[data-ph-call-form]');assert.ok(q('[data-ph-call-log]').textContent.includes('<img src=x'));assert.equal(qa('[data-ph-call-log] img').length,0);assert.equal(q('[data-turns]').innerHTML,narrative);assert.equal(input.value,'Действие за столом');assert.equal(qa('[data-choice]').length,6);
  click('[data-ph-hangup]');assert.equal(q('[data-ph-call-form]'),null);click('[data-ph-back-calls]');assert.ok(q('[data-ph-open-record]'));click('[data-ph-open-record]');assert.ok(q('[data-ph-call-log]').textContent.includes('<img src=x'));assert.equal(q('[data-ph-call-form]'),null);click('[data-ph-close]');assert.equal(q('.nr-choices').hidden,false);assert.equal(input.value,'Действие за столом');
});
test('Closing an active phone call ends it and retains a read-only history entry',({q,click,runTimers})=>{
  click('.nr-phonebutton');click('[data-ph-thread="sonya"]');click('[data-ph-call="sonya"]');runTimers();assert.ok(q('[data-ph-call-form]'));click('[data-ph-close]');click('.nr-phonebutton');assert.ok(q('[data-ph-open-record]'));assert.equal(q('[data-ph-resume]'),null);click('[data-ph-open-record]');assert.equal(q('[data-ph-call-form]'),null);
});
test('Phone drafts belong to the controlled actor and restore when returning',({q,click,type,change})=>{
  click('.nr-phonebutton');click('[data-ph-thread="sonya"]');type('[data-ph-input]','Личный черновик Ильи');click('[data-ph-close]');change('#nr-actor','Катя');click('.nr-phonebutton');assert.match(q('.ph-owner').textContent,/Катя/);click('[data-ph-tab="contacts"]');assert.ok(!q('[data-ph-contact-list]').textContent.includes('Катя Соколова'));click('[data-ph-close]');change('#nr-actor','Илья');click('.nr-phonebutton');assert.equal(q('[data-ph-input]').value,'Личный черновик Ильи');
});
test('A world without characters does not inherit Santa Rosa phone contacts or owner',({q,qa,ui,click})=>{
  ui.switchCampaign({worldId:'empty-world',worldName:'Пустой мир',saveId:'empty-save',saveName:'Новый запуск',location:'Начальная сцена',people:[]});
  assert.equal(ui.state.actor,null);assert.equal(ui.state.protagonist,null);assert.equal(ui.state.people.length,0);assert.equal(qa('[data-ph-thread]').length,0);assert.doesNotMatch(q('.ph-owner').textContent,/Илья|Соня|Тимур|Катя/);
  if(!q('.nr-phonebutton').disabled){click('.nr-phonebutton');assert.doesNotMatch(q('.ph-content').textContent,/Илья|Соня|Тимур|Катя/);}
});

const report={passed:results.filter(x=>x.passed).length,total:results.length,failed:results.filter(x=>!x.passed),limits:'DOM behavior only. Layout, font rendering, real mobile viewport, animation smoothness and network/backend were not tested.'};
console.log(JSON.stringify(report,null,2));
process.exitCode=report.failed.length?1:0;

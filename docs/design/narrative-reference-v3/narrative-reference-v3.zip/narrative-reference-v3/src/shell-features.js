(function () {
  'use strict';
  window.installNarrativeShellFeatures = function (root, ui) {
    const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    const icon = name => '<i data-lucide="' + name + '" aria-hidden="true"></i>';
    const button = (label, action, extra = '', primary = false) => '<button type="button" class="ui-button' + (primary ? ' primary' : '') + '" data-sf-action="' + action + '" ' + extra + '>' + label + '</button>';
    const chip = '<span class="sf-demo-chip">Демо</span>';
    let serial = 10;
    const worlds = [
      {id:'santa',name:'Санта-Роса: вечер в кругу друзей',short:'Санта-Роса',icon:'sunset',tone:'santa',genre:'Современность · повседневность',location:'Семейная квартира Волковых',summary:'Летний вечер, общий стол и разговоры, которые никто не торопится заканчивать. У каждого за этим столом — своя жизнь за пределами сцены.',people:['Илья Волков','Мёрфи Волкова','Тимур Савельев','Соня Величкина','Катя Соколова'],saves:[{id:'santa-main',name:'Новое прохождение',hint:'Семейная квартира · 20:08'},{id:'santa-evening',name:'Другой вечер',hint:'Отдельное прохождение'}],source:'Санта-Роса. Современный мир, июль 2026 года.\n\nВ центре сцены — Илья, Мёрфи, Тимур, Соня и Катя. Они собрались в семейной квартире Волковых.\n\nТон: живые диалоги, бытовые детали, самостоятельные NPC. Решения управляемого персонажа задаёт игрок.'},
      {id:'birch',name:'Берёзовск: после дождя',short:'Берёзовск',icon:'trees',tone:'birch',genre:'Маленький город · современность',location:'Кафе у вокзала',summary:'Последний автобус ушёл. За стеклом кафе отражаются мокрые фонари, а на столе остывает второй чай.',people:['Алексей','Нина','Виктор'],saves:[{id:'birch-main',name:'После дождя',hint:'Кафе у вокзала'}],source:'Демонстрационный мир. Берёзовск, небольшой город у железной дороги.\n\nАлексей ждёт в кафе у вокзала. Нина закрывает смену, Виктор рассматривает расписание.\n\nТон: сдержанный реализм, внимание к людям и месту.'},
      {id:'orbit',name:'Орбитальная станция «Эхо»',short:'Станция «Эхо»',icon:'orbit',tone:'orbit',genre:'Ближний космос · научная фантастика',location:'Общий отсек станции «Эхо»',summary:'За иллюминатором медленно поворачивается Земля. Ночная смена только начинается; в общем отсеке ещё горит тёплый свет.',people:['Алекс','Мира','Леон'],saves:[{id:'orbit-main',name:'Ночная смена',hint:'Общий отсек станции'}],source:'Демонстрационный мир. Орбитальная станция «Эхо».\n\nМира, Леон и Алекс готовятся к ночной смене. Станция работает штатно.\n\nТон: приземлённая научная фантастика, личные отношения, жизнь небольшого экипажа.'}
    ];
    const removed = [];
    let selectedWorld = ui.state.worldId || 'santa';
    let worldSection = 'Мир';
    let showEventSamples = false;
    let eventFilter = 'all';
    const getWorld = id => worlds.find(w => w.id === id) || removed.find(w => w.id === id) || worlds[0];
    const currentWorld = () => getWorld(ui.state.worldId);
    function wire(body, handlers) {
      body.addEventListener('click', event => {
        const target = event.target.closest('[data-sf-action]');
        if (!target || !body.contains(target) || target.disabled) return;
        const handler = handlers[target.dataset.sfAction];
        if (handler) handler(target, event);
      });
      body.addEventListener('keydown', event => {
        const target = event.target.closest('[role="tab"]');
        if (!target || !['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) return;
        const tabs = [...target.parentElement.querySelectorAll('[role="tab"]')];
        const index = tabs.indexOf(target);
        const next = event.key === 'Home' ? tabs[0] : event.key === 'End' ? tabs[tabs.length - 1] : tabs[(index + (event.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length];
        event.preventDefault(); next.click(); root.querySelector('.sf-tabs [aria-selected="true"]')?.focus();
      });
      ui.icons();
      return body;
    }
    function modal(title, subtitle, html, wide = true, kind = 'confirm') {
      const host = ui.modal({title, subtitle, html:'<div class="sf-surface">' + html + '</div>', size:wide ? 'wide' : 'normal',kind});
      return host.firstElementChild;
    }
    function tabs(items, active, action, label) {
      return '<div class="ui-tabs sf-tabs" role="tablist" aria-label="' + esc(label) + '">' + items.map(([id,name]) => '<button type="button" role="tab" aria-selected="' + (active === id) + '" data-sf-action="' + action + '" data-value="' + esc(id) + '">' + esc(name) + '</button>').join('') + '</div>';
    }
    function launch(world, save) {
      ui.switchCampaign({worldId:world.id,worldName:world.name,saveId:save.id,saveName:save.name,location:world.location,people:world.people});
      ui.close();
      ui.notice('Прохождение «' + save.name + '» открыто');
    }
    function renderWorlds() {
      let selected = worlds.find(w => w.id === selectedWorld) || worlds[0];
      if (selected) selectedWorld = selected.id;
      const html = '<div class="sf-topline"><span class="ui-subtle">' + worlds.length + ' мира</span><div class="sf-inline-actions">' + button(icon('messages-square')+'RP-чат · кампании','chat') + button(icon('plus')+'Создать мир','create-world') + '</div></div>' +
        '<div class="sf-worlds-layout"><label class="sf-world-mobile">Выбрать мир<select data-sf-world-select aria-label="Выбрать мир">'+worlds.map(w=>'<option value="'+esc(w.id)+'"'+(w.id===selectedWorld?' selected':'')+'>'+esc(w.name)+'</option>').join('')+'</select></label><div class="sf-worldlist" aria-label="Миры">' + worlds.map(w => '<button type="button" class="sf-world-tile sf-tone-' + w.tone + '" aria-pressed="' + (w.id === selectedWorld) + '" data-sf-action="select-world" data-id="' + esc(w.id) + '"><span class="sf-world-symbol">' + icon(w.icon) + '</span><span class="sf-world-copy"><small>' + esc(w.genre) + '</small><strong>' + esc(w.short) + '</strong><span>' + w.saves.length + ' ' + (w.saves.length === 1 ? 'прохождение' : 'прохождения') + '</span></span>' + (w.id === ui.state.worldId ? '<span class="sf-world-current">В игре</span>' : '') + '</button>').join('') + (!worlds.length ? '<p class="ui-subtle">Пока нет миров. Создай мир или восстанови его из корзины.</p>' : '') + '</div>' +
        '<div class="sf-world-detail">' + (selected ? '<div class="sf-section-head"><div><span class="sf-kicker">ВЫБРАННЫЙ МИР</span><h3>' + esc(selected.name) + '</h3></div><button type="button" class="sf-icon-button" data-sf-action="remove-world" aria-label="Переместить мир в корзину">' + icon('trash-2') + '</button></div><p class="sf-description">' + esc(selected.summary) + '</p><h4>Прохождения</h4><div class="sf-save-list">' + selected.saves.map(save => '<button type="button" class="sf-save" data-sf-action="continue" data-id="' + esc(save.id) + '"><span class="sf-save-icon">' + icon('play') + '</span><span><strong>' + esc(save.name) + '</strong><small>Narrative · ' + esc(save.hint) + '</small></span>' + (save.id === ui.state.saveId ? '<span class="sf-tag">Текущее</span>' : '') + icon('arrow-up-right') + '</button>').join('') + '</div>' + button(icon('globe')+'Посмотреть исходный мир','source') + '<details class="sf-disclosure sf-create-save"><summary>' + icon('plus') + 'Новое прохождение</summary><form data-sf-save-form><div class="sf-form-grid"><label class="ui-field">Название<input name="name" required maxlength="80" placeholder="Новое прохождение" value="Новое прохождение"></label><label class="ui-field">Режим<select name="mode"><option value="narrative">Narrative</option><option value="chat">RP-чат</option></select></label></div><button class="ui-button primary" type="submit">' + icon('plus') + 'Создать прохождение</button><p class="ui-subtle sf-fineprint">Новое прохождение начнётся независимо от текущего.</p></form></details>' : '') + '</div></div>' +
        '<div class="sf-secondary-disclosures"><details class="sf-disclosure"><summary>' + icon('upload') + 'Загрузить готовую выжимку</summary><form data-sf-import-form><div class="sf-form-grid"><label class="ui-field">Название мира<input name="worldName" required maxlength="80" placeholder="Название нового мира"></label><label class="ui-field">Markdown-файл · UTF-8<input name="file" type="file" accept=".md,text/markdown,text/plain"></label></div><label class="ui-field">Текст выжимки<textarea name="markdown" rows="4" required placeholder="Или вставь Markdown…"></textarea></label><button class="ui-button" type="submit">' + icon('upload') + 'Добавить мир</button></form></details><details class="sf-disclosure"><summary>' + icon('trash-2') + 'Удалённые миры <span class="sf-count">' + removed.length + '</span></summary>' + (removed.length ? removed.map(w => '<div class="sf-trash-row"><span>' + esc(w.name) + '</span>' + button('Восстановить','restore','data-id="' + esc(w.id) + '"') + '</div>').join('') : '<p class="ui-subtle">Корзина пуста.</p>') + '</details></div>';
      const body = modal('Миры и прохождения','Твои миры, сохранённые прохождения и новые начала.',html,true,'worlds');
      wire(body, {
        'select-world': b => {selectedWorld = b.dataset.id; renderWorlds();},
        'continue': b => launch(selected, selected.saves.find(s => s.id === b.dataset.id)),
        'source': () => renderInspector('Мир',selected,true),
        'chat': () => renderChatLibrary(),
        'create-world': () => renderCreator(),
        'remove-world': () => {
          const confirm = modal('Переместить мир в корзину?',selected.name,'<p class="sf-description">Мир вместе с прохождениями переместится в корзину. Его можно восстановить позже.</p><div class="sf-inline-actions">' + button('Отмена','cancel') + button('В корзину','confirm','',true)+'</div>',false);
          wire(confirm,{'cancel':renderWorlds,'confirm':() => {removed.push(selected); worlds.splice(worlds.indexOf(selected),1); selectedWorld = worlds[0]?.id; renderWorlds(); ui.notice('Мир перемещён в корзину');}});
        },
        'restore': b => {const world = removed.find(w => w.id === b.dataset.id); if (world) {removed.splice(removed.indexOf(world),1);worlds.push(world);selectedWorld = world.id;renderWorlds();ui.notice('Мир восстановлен');}}
      });
      body.querySelector('[data-sf-world-select]')?.addEventListener('change',event=>{selectedWorld=event.target.value;renderWorlds();});
      const saveForm = body.querySelector('[data-sf-save-form]');
      saveForm?.addEventListener('submit', event => {
        event.preventDefault();
        const data = new FormData(saveForm); const name = String(data.get('name') || '').trim();
        if (!name) return;
        if (data.get('mode') === 'chat') {renderChatCreator(selected,name);return;}
        const save = {id:selected.id + '-demo-' + (++serial),name,hint:selected.location + ' · новое демо'};
        selected.saves.push(save); launch(selected,save);
      });
      const importForm = body.querySelector('[data-sf-import-form]');
      importForm.elements.file.addEventListener('change',async event => {
        const file = event.target.files?.[0]; if (!file) return;
        if (file.size > 2 * 1024 * 1024) {ui.notice('Для демо выбери Markdown до 2 МБ');event.target.value='';return;}
        try {importForm.elements.markdown.value = new TextDecoder('utf-8',{fatal:true}).decode(await file.arrayBuffer());if (!importForm.elements.worldName.value.trim()) importForm.elements.worldName.value = file.name.replace(/\.md$/i,'');}
        catch (_) {ui.notice('Не удалось прочитать файл в UTF-8');}
      });
      importForm.addEventListener('submit',event => {
        event.preventDefault(); const name = importForm.elements.worldName.value.trim(); const source = importForm.elements.markdown.value.trim();
        if (!name || !source) return;
        const world = {id:'import-'+(++serial),name,short:name,icon:'globe',tone:'birch',genre:'Импортированный мир · демо',location:'Начальная сцена',summary:'Мир добавлен из выжимки. Исходный текст доступен для просмотра.',people:[],saves:[],source};
        worlds.push(world);selectedWorld=world.id;renderWorlds();ui.notice('Мир добавлен только в демо');
      });
    }
    function renderCreator() {
      const body = modal('Новый мир','Название, замысел и первая сцена нового мира.',
        '<form data-sf-create-world><label class="ui-field">Название мира<input name="name" required maxlength="80" placeholder="Например, город у моря"></label><label class="ui-field">Замысел и начальная сцена<textarea name="idea" rows="6" required placeholder="Где начинается игра? Кто рядом? Что происходит сейчас?"></textarea></label><p class="ui-subtle">В концепте мир создаётся из введённого текста. Генерация не подключена.</p><div class="sf-inline-actions">' + button('К мирам','back') + '<button class="ui-button primary" type="submit">' + icon('plus') + 'Создать мир</button></div></form>',false);
      wire(body,{'back':renderWorlds});
      body.querySelector('form').addEventListener('submit',event => {
        event.preventDefault(); const form = event.currentTarget; const name = form.elements.name.value.trim(); const idea = form.elements.idea.value.trim(); if (!name || !idea) return;
        const world = {id:'created-'+(++serial),name,short:name,icon:'globe',tone:'santa',genre:'Авторский мир · демо',location:'Начальная сцена',summary:idea,people:[],saves:[],source:idea};
        worlds.push(world);selectedWorld=world.id;renderWorlds();ui.notice('Демо-мир создан. Можно начать прохождение.');
      });
    }

    const chats = [
      {id:'chat-santa',worldId:'santa',name:'Санта-Роса · свободный вечер',draft:'',memory:'Современная Санта-Роса. Илья, Мёрфи, Соня, Тимур и Катя собрались за ужином. Авторская выжимка — отдельный документ RP-кампании.',messages:[{role:'assistant',text:'За окном окончательно темнеет. Тимур убирает со стола пустое блюдо, а Соня закрывает блокнот.\n— Ну что, — спрашивает Катя, — у кого ещё есть планы на вечер?'}],branches:[],chapter:'Вечер в Санта-Росе'},
      {id:'chat-birch',worldId:'birch',name:'Берёзовск · разговор в кафе',draft:'',memory:'Небольшой город, вечер после дождя. Кафе у вокзала. Алексей, Нина и Виктор.',messages:[{role:'assistant',text:'Кофемашина затихает. Нина смотрит на часы и оставляет свет над твоим столиком.\n— До поезда ещё сорок минут. Чаю?'}],branches:[],chapter:'После дождя'}
    ];
    let activeChat = null;
    const chatReplies = {
      santa:['Тимур усмехается и ставит чашку на край стола.\n— Вот теперь вечер становится интереснее.\nСоня поворачивается к нему, ожидая продолжения.','Мёрфи переводит взгляд с одного взрослого на другого.\n— Только давайте без скучных правил, — говорит она.'],
      birch:['Нина кивает и берёт чистую чашку. За окном, разрезая отражения фонарей, проходит человек с закрытым зонтом.','Дверь кафе звякает. Виктор поднимает глаза от расписания и отодвигает соседний стул.'],
      orbit:['Мира убирает планшет и разворачивается к иллюминатору.\n— Через две минуты пройдём над побережьем. Отсюда оно почти всегда в облаках.','Леон прикрепляет кружку к столу. Из коридора доносится ровный шум вентиляции.']
    };
    function renderChatLibrary() {
      const body = modal('Кампании RP-чата','Выбери разговор или начни новую кампанию.',
        '<div class="sf-topline">' + button(icon('arrow-left')+'В Narrative','narrative') + '</div><div class="sf-chat-library"><div class="sf-chat-intro">' + icon('messages-square') + '<h3>Продолжить разговор</h3><p>Открой кампанию или подготовь новую выжимку.</p></div><div class="sf-save-list">' + chats.map(c => '<button type="button" class="sf-save" data-sf-action="open-chat" data-id="'+c.id+'"><span class="sf-save-icon">'+icon('messages-square')+'</span><span><strong>'+esc(c.name)+'</strong><small>RP-чат · '+esc(c.chapter)+'</small></span>'+icon('arrow-up-right')+'</button>').join('') + '</div><div class="sf-inline-actions">' + button(icon('plus')+'Новая RP-кампания','create','',true) + button(icon('globe')+'Миры Narrative','worlds') + '</div></div>',true,'chat');
      wire(body,{'narrative':()=>ui.close(),'open-chat':b=>{activeChat=b.dataset.id;renderChat();},'create':()=>renderChatCreator(currentWorld()),'worlds':renderWorlds});
    }
    function renderChatCreator(world,name='Новая RP-кампания') {
      const body=modal('Новая RP-кампания','Проверь и утверди авторскую выжимку перед началом.',
        '<form data-sf-create-chat><label class="ui-field">Название кампании<input name="name" required maxlength="80" value="'+esc(name)+'"></label><label class="ui-field">Авторская выжимка<textarea name="memory" required rows="7">'+esc(world?.source || 'Опиши мир и начальную сцену.')+'</textarea></label><p class="ui-subtle">'+chip+' Создаётся отдельная копия. Прохождение Narrative остаётся на своём месте.</p><div class="sf-inline-actions">'+button('К кампаниям','back')+'<button class="ui-button primary" type="submit">'+icon('check')+'Утвердить выжимку и начать</button></div></form>',false);
      wire(body,{'back':renderChatLibrary});
      body.querySelector('form').addEventListener('submit',event=>{event.preventDefault();const form=event.currentTarget;const name=form.elements.name.value.trim();const memory=form.elements.memory.value.trim();if(!name||!memory)return;
        const c={id:'chat-demo-'+(++serial),worldId:world?.id || 'santa',name,draft:'',memory,messages:[{role:'assistant',text:world?.id==='orbit'?'В общем отсеке станции горит приглушённый свет. Мира отрывается от планшета и смотрит на вошедшего.':world?.id==='birch'?'За стеклом кафе блестят мокрые рельсы. Нина оставляет чашку на столе.':'В комнате становится тише. Разговор ещё не закончился; у тебя есть время выбрать слова.'}],branches:[],chapter:'Начальная сцена'};
        chats.push(c);activeChat=c.id;renderChat();});
    }
    function renderChat() {
      const c=chats.find(x=>x.id===activeChat);if(!c){renderChatLibrary();return;}
      const body=modal(c.name,'RP-чат · '+c.chapter,
        '<div class="sf-chat-toolbar"><div class="sf-inline-actions">'+button(icon('arrow-left')+'В Narrative','narrative')+button(icon('layers-2')+'Кампании','campaigns')+'</div></div><div class="sf-chat-subbar"><span>'+esc(c.chapter)+'</span><div class="sf-inline-actions">'+button(icon('git-branch')+'<span class="sf-chat-long">Главы и ветки</span><span class="sf-chat-short">Ветки</span>','branches')+button(icon('file-text')+'Выжимка','memory')+button(icon('settings-2')+'Настройки','settings')+'</div></div><div class="sf-chat-messages" role="log" aria-live="polite" aria-label="Переписка RP-чата">'+c.messages.map((m,i)=>'<article class="sf-chat-message sf-chat-'+m.role+'"><header><strong>'+ (m.role==='user'?'Ты':'Ведущий')+'</strong><span>'+(m.role==='assistant'?'':'')+'</span><button type="button" class="sf-icon-button" data-sf-action="bookmark" data-index="'+i+'" aria-label="'+(m.bookmark?'Удалить закладку':'Добавить закладку')+'" aria-pressed="'+!!m.bookmark+'">'+icon(m.bookmark?'bookmark-check':'bookmark')+'</button></header><p>'+esc(m.text)+'</p></article>').join('')+'</div><form class="sf-chat-composer" data-sf-chat-form><label class="ui-field"><span class="sf-sr">Твоё сообщение в RP-чате</span><textarea name="text" rows="2" maxlength="4000" placeholder="Действие или реплика…">'+esc(c.draft)+'</textarea></label><div class="sf-inline-actions"><small class="ui-subtle">Ctrl / ⌘ + Enter — отправить</small><button class="ui-button primary" type="submit" '+(!c.draft.trim()?'disabled':'')+'>'+icon('send')+'Отправить</button></div></form>',true,'chat');
      body.classList.add('sf-chat-workspace');
      wire(body,{'narrative':()=>ui.close(),'campaigns':renderChatLibrary,'memory':()=>renderChatMemory(c),'branches':()=>renderBranches(c),'settings':()=>renderSettings('models',renderChat),'bookmark':b=>{c.messages[+b.dataset.index].bookmark=!c.messages[+b.dataset.index].bookmark;const y=body.querySelector('.sf-chat-messages').scrollTop;renderChat();root.querySelector('.sf-chat-messages').scrollTop=y;}});
      const form=body.querySelector('form');const input=form.elements.text;const submit=form.querySelector('[type="submit"]');
      input.addEventListener('input',()=>{c.draft=input.value;submit.disabled=!c.draft.trim();});
      input.addEventListener('keydown',event=>{if(event.key==='Enter'&&(event.ctrlKey||event.metaKey)&&!event.isComposing){event.preventDefault();if(input.value.trim())form.requestSubmit();}});
      form.addEventListener('submit',event=>{event.preventDefault();const text=input.value.trim();if(!text)return;const replies=chatReplies[c.worldId]||chatReplies.santa;const count=c.messages.filter(m=>m.role==='user').length;c.messages.push({role:'user',text},{role:'assistant',text:replies[count%replies.length]});c.draft='';renderChat();root.querySelector('[data-sf-chat-form] textarea')?.focus();});
      const log=body.querySelector('.sf-chat-messages');log.scrollTop=log.scrollHeight;
    }
    function renderChatMemory(c) {
      const body=modal('Авторская выжимка','Память текущей RP-кампании. Проверь изменения перед сохранением.',
        '<form data-sf-memory-form><label class="ui-field">Утверждённая память<textarea name="memory" rows="10" required>'+esc(c.memory)+'</textarea></label><div class="sf-inline-actions">'+button(icon('arrow-left')+'К переписке','back')+'<button type="submit" class="ui-button primary">'+icon('check')+'Утвердить изменения</button></div></form>',false);
      wire(body,{'back':renderChat});body.querySelector('form').addEventListener('submit',e=>{e.preventDefault();const value=e.currentTarget.elements.memory.value.trim();if(!value)return;c.memory=value;renderChat();ui.notice('Авторская память обновлена в демо-кампании');});
    }
    function renderBranches(c) {
      const body=modal('Главы и ветки','Сохранённые продолжения текущей кампании.',
        '<div class="sf-section-head"><div><span class="sf-kicker">АКТИВНОЕ ПРОДОЛЖЕНИЕ</span><h3>'+esc(c.chapter)+'</h3></div><span class="sf-tag">'+c.messages.length+' сообщ.</span></div><p class="ui-subtle">Сохранённая ветка фиксирует текущую переписку. Её можно открыть отдельно.</p><div class="sf-save-list">'+c.branches.map((b,i)=>'<button type="button" class="sf-save" data-sf-action="branch" data-index="'+i+'"><span class="sf-save-icon">'+icon('git-branch')+'</span><span><strong>'+esc(b.name)+'</strong><small>'+b.messages.length+' сообщений</small></span>'+icon('arrow-up-right')+'</button>').join('')+'</div><form data-sf-branch-form><label class="ui-field">Название ветки<input name="name" required maxlength="70" value="Вариант '+(c.branches.length+1)+'"></label><div class="sf-inline-actions">'+button(icon('arrow-left')+'К переписке','back')+'<button type="submit" class="ui-button primary">'+icon('git-branch')+'Сохранить ветку</button></div></form>',false);
      wire(body,{'back':renderChat,'branch':b=>{const branch=c.branches[+b.dataset.index];const copy={...c,id:'chat-branch-'+(++serial),name:c.name+' · '+branch.name,draft:'',messages:branch.messages.map(m=>({...m})),branches:[]};chats.push(copy);activeChat=copy.id;renderChat();ui.notice('Открыта отдельная копия ветки');}});
      body.querySelector('form').addEventListener('submit',e=>{e.preventDefault();const name=e.currentTarget.elements.name.value.trim();if(!name)return;c.branches.push({name,messages:c.messages.map(m=>({...m}))});renderBranches(c);ui.notice('Ветка сохранена в демо');});
    }

    const defaults={font:17,line:1.8,width:820,skin:'graphite',links:true,motion:true,recent:8,models:{idea:{provider:'deepseek',model:'deepseek-flash',context:32768,output:4096,temperature:0.8,auto:true},summary:{provider:'deepseek',model:'deepseek-flash',context:32768,output:8192,temperature:0.5,auto:true},game:{provider:'deepseek',model:'deepseek-flash',context:32768,output:8192,temperature:0.9,auto:true}}};
    let prefs=JSON.parse(JSON.stringify(defaults));
    function applyAppearance() {
      root.style.setProperty('--sf-font-size',prefs.font+'px');root.style.setProperty('--sf-line-height',prefs.line);root.style.setProperty('--sf-reading-width',prefs.width+'px');root.dataset.sfSkin=prefs.skin;root.dataset.sfLinks=String(prefs.links);root.dataset.sfMotion=String(prefs.motion);
      root.querySelectorAll('.nr-inlineperson').forEach(name=>{name.disabled=!prefs.links;});
      const schemes={graphite:['#131517','#d2b477','#302b22'],midnight:['#131923','#a9bfdc','#273343'],warm:['#1a1817','#cfa989','#372d26']};
      const colors=schemes[prefs.skin];root.style.setProperty('--nr-bg',colors[0]);root.style.setProperty('--nr-accent',colors[1]);root.style.setProperty('--nr-accentbg',colors[2]);
      root.querySelector('[data-motion]').checked=prefs.motion;root.querySelectorAll('[data-font-size]').forEach(button=>button.setAttribute('aria-pressed',String(({small:14,normal:16,large:18})[button.dataset.fontSize]===prefs.font)));
    }
    function renderSettings(tab='models',back=null) {
      if(!['models','context','appearance'].includes(tab))tab='models';
      const headings=[['idea','Сценарист','Замысел и подготовка сцены'],['summary','Генератор мира и выжимки','Структура мира и память'],['game','Ведущий','Повествование и обработка мира']];
      let content='';
      if(tab==='models') content='<div class="sf-connection"><span class="sf-connection-icon">'+icon('plug-zap')+'</span><div><strong>Подключения</strong><p>В макете подключения не активны. API-ключ не требуется.</p></div></div>'+headings.map(([key,title,note])=>{const m=prefs.models[key];return '<section class="sf-model-section"><div class="sf-section-head"><div><h3>'+title+'</h3><p class="ui-subtle">'+note+'</p></div>'+icon(key==='game'?'messages-square':key==='idea'?'lightbulb':'layers-2')+'</div><div class="sf-form-grid"><label class="ui-field">Провайдер<select data-model="'+key+'" data-key="provider"><option value="deepseek" '+(m.provider==='deepseek'?'selected':'')+'>DeepSeek API</option><option value="local" '+(m.provider==='local'?'selected':'')+'>Локальная · LM Studio</option><option value="compatible" '+(m.provider==='compatible'?'selected':'')+'>OpenAI-совместимый API</option></select></label><label class="ui-field">Модель<input data-model="'+key+'" data-key="model" value="'+esc(m.model)+'" maxlength="100"></label></div><details class="sf-disclosure"><summary>Лимиты и параметры</summary><label class="sf-check"><input type="checkbox" data-model="'+key+'" data-key="auto" '+(m.auto?'checked':'')+'>Контекст и лимиты — автоматически</label><div class="sf-form-grid sf-three-columns"><label class="ui-field">Бюджет контекста<input type="number" min="2048" max="1048576" data-model="'+key+'" data-key="context" value="'+m.context+'" '+(m.auto?'disabled':'')+'></label><label class="ui-field">Лимит ответа<input type="number" min="256" max="65536" data-model="'+key+'" data-key="output" value="'+m.output+'" '+(m.auto?'disabled':'')+'></label><label class="ui-field">Temperature<input type="number" min="0" max="1.5" step="0.05" data-model="'+key+'" data-key="temperature" value="'+m.temperature+'"></label></div></details></section>';}).join('');
      if(tab==='context') content='<section class="sf-model-section"><h3>Память прохождения</h3><p class="sf-description">Количество последних ходов, которые ведущий получает вместе с контекстом мира.</p><label class="ui-field sf-narrow-field">Последних ходов в контексте<input type="number" min="2" max="20" value="'+prefs.recent+'" data-pref="recent"></label></section><section class="sf-model-section"><h3>Бюджет по задачам</h3><p class="ui-subtle">Контекст, лимит ответа и Temperature настраиваются отдельно для каждой модели.</p>'+button(icon('settings-2')+'К параметрам моделей','model-tab')+'</section><details class="sf-disclosure"><summary>Основные промпты и версии</summary><p class="ui-subtle">Демонстрационный обзор. Серверные промпты не загружены.</p><div class="sf-prompt-list"><div><strong>Сценарист</strong><span>Подготовка замысла</span></div><div><strong>Генератор мира и выжимки</strong><span>Мир и авторская память</span></div><div><strong>Ведущий</strong><span>Игровой ход</span></div></div></details>';
      if(tab==='appearance') content='<section class="sf-model-section"><h3>Тема мира</h3><div class="sf-skin-options">'+[['graphite','Графит'],['midnight','Ночной'],['warm','Тёплый']].map(([id,name])=>'<button type="button" class="sf-skin sf-skin-'+id+'" data-sf-action="skin" data-value="'+id+'" aria-pressed="'+(prefs.skin===id)+'"><span><i></i><i></i><i></i></span>'+name+(prefs.skin===id?icon('check'):'')+'</button>').join('')+'</div></section><section class="sf-model-section"><h3>Текст и плотность</h3>'+[['font','Размер текста',14,24,1,'px'],['line','Межстрочный интервал',1.3,2.2,0.05,''],['width','Ширина текста',600,1100,25,'px']].map(([key,label,min,max,step,suffix])=>'<label class="sf-range"><span>'+label+'<output data-output="'+key+'">'+prefs[key]+' '+suffix+'</output></span><input type="range" data-pref="'+key+'" min="'+min+'" max="'+max+'" step="'+step+'" value="'+prefs[key]+'"></label>').join('')+'<div class="sf-type-preview"><span class="sf-kicker">ПРЕДПРОСМОТР</span><p>Соня закрывает блокнот и поднимает глаза. За окном уже темнеет, но за столом никто не торопится расходиться.</p></div><label class="sf-check"><input type="checkbox" data-pref="links" '+(prefs.links?'checked':'')+'>Ссылки на персонажей в повествовании</label><label class="sf-check"><input type="checkbox" data-pref="motion" '+(prefs.motion?'checked':'')+'>Плавные анимации</label></section>';
      const body=modal('Настройки','Модели, контекст и внешний вид приложения.',
        tabs([['models','Модели'],['context','Контекст'],['appearance','Оформление']],tab,'settings-tab','Разделы настроек')+'<div class="sf-settings-content">'+content+'</div><div class="sf-settings-footer">'+button('По умолчанию','defaults')+'<div class="sf-inline-actions">'+(back?button(icon('arrow-left')+'К RP-чату','back'):'')+button(icon('check')+'Применить','apply','',true)+'</div></div>',true,'settings');
      wire(body,{'settings-tab':b=>renderSettings(b.dataset.value,back),'model-tab':()=>renderSettings('models',back),'defaults':()=>{prefs=JSON.parse(JSON.stringify(defaults));applyAppearance();renderSettings(tab,back);ui.notice('Демонстрационные настройки сброшены');},'skin':b=>{prefs.skin=b.dataset.value;applyAppearance();renderSettings('appearance',back);},'apply':()=>{applyAppearance();if(back)back();else ui.close();ui.notice('Настройки применены в текущем демо');},'back':()=>back?.()});
      body.addEventListener('input',event=>{const target=event.target;if(target.dataset.pref){const key=target.dataset.pref;prefs[key]=target.type==='checkbox'?target.checked:+target.value;if(['font','line','width','links','motion'].includes(key))applyAppearance();const out=body.querySelector('[data-output="'+key+'"]');if(out)out.textContent=prefs[key]+(key==='line'?'':' px');}if(target.dataset.model){const m=prefs.models[target.dataset.model];const key=target.dataset.key;m[key]=target.type==='checkbox'?target.checked:target.type==='number'?+target.value:target.value;if(key==='auto'){const section=target.closest('.sf-model-section');section.querySelectorAll('[data-key="context"],[data-key="output"]').forEach(input=>{input.disabled=m.auto;});}}});
    }

    const inspectorSections=[['Мир','globe'],['Сцена','map-pin'],['Персонажи','users'],['Отношения','heart'],['Сюжет','git-branch'],['Память','history'],['Тайны','lock-keyhole'],['Родословная','network'],['Сведения','sliders-horizontal']];
    const sectionAliases={world:'Мир',scene:'Сцена',characters:'Персонажи',relations:'Отношения',threads:'Сюжет',plot:'Сюжет',memory:'Память',secrets:'Тайны',genealogy:'Родословная',family:'Родословная',settings:'Сведения','Настройки и сведения о мире':'Сведения'};
    const sampleEvents=[{id:'thread-dinner',kind:'thread',icon:'git-branch',label:'Новая сюжетная линия',title:'Планы на субботу',text:'За столом начали обсуждать поездку на выходные.',turn:4,section:'Сюжет'},{id:'secret-notebook',kind:'secret',icon:'sparkles',label:'Новая тайна',title:'Заметки Сони',text:'Соня делает заметки, но их содержание Илье пока неизвестно.',turn:3,section:'Тайны'},{id:'secret-gift',kind:'secret',icon:'key-round',label:'Раскрыта тайна',title:'Подарок для Мёрфи',text:'Катя рассказала Илье о подготовленном сюрпризе.',turn:2,section:'Тайны'}];
    function inspectorContent(section,world,baseline,highlight) {
      const santa=world.id==='santa';const scene=world.id===ui.state.worldId?ui.state.location||world.location:world.location;const time=Math.floor(ui.state.minutes/60).toString().padStart(2,'0')+':'+(ui.state.minutes%60).toString().padStart(2,'0');
      if(baseline) return '<div class="sf-section-head"><div><span class="sf-kicker">ИСХОДНЫЙ МИР · ОСНОВА</span><h3>'+esc(world.name)+'</h3></div>'+chip+'</div><p class="ui-subtle">Это основа мира. Просмотр не переключает активное прохождение.</p><pre class="sf-source">'+esc(world.source)+'</pre>'+button(icon('arrow-left')+'К мирам и прохождениям','worlds');
      if(section==='Мир')return '<span class="sf-kicker">ОБЗОР МИРА</span><h3>'+esc(world.name)+'</h3><p class="sf-description">'+esc(world.summary)+'</p><div class="sf-facts"><div><small>Текущее место</small><strong>'+esc(scene)+'</strong></div><div><small>Прохождение</small><strong>'+esc(ui.state.saveName)+'</strong></div><div><small>Под управлением</small><strong>'+esc(ui.state.observer?'Мир без главного героя':ui.state.actor)+'</strong></div></div><div class="sf-inline-actions">'+button(icon('map-pin')+'Текущая сцена','section','data-value="Сцена"')+button(icon('calendar-days')+'Календарь','calendar')+'</div>';
      if(section==='Сцена')return '<span class="sf-kicker">ТЕКУЩАЯ СЦЕНА</span><h3>'+esc(scene)+'</h3><p class="sf-description">'+esc(santa?'Вечер в квартире Волковых. На столе ещё остался ужин; разговор перескакивает с шуток на планы.':world.summary)+'</p><div class="sf-facts"><div><small>Время</small><strong>'+time+'</strong></div><div><small>Камера и управление</small><strong>'+esc(ui.state.observer?'Камера наблюдателя':ui.state.actor)+'</strong></div></div><h4>Участники сцены</h4><div class="sf-people-grid">'+world.people.map((name,i)=>'<button type="button" class="sf-person" data-sf-action="person" data-name="'+esc(name)+'"><span class="sf-avatar sf-av-'+i+'">'+esc(name.split(' ').map(x=>x[0]).slice(0,2).join(''))+'</span><span>'+esc(name)+'</span>'+icon('chevron-right')+'</button>').join('')+'</div>'+button(icon('history')+'События сцены','section','data-value="Память"');
      if(section==='Персонажи')return '<span class="sf-kicker">МИР И ПЕРСОНАЖИ</span><h3>Участники</h3><p class="ui-subtle">'+chip+' Карточки персонажей демонстрационного мира.</p><label class="ui-field"><span class="sf-sr">Найти персонажа</span><input type="search" data-sf-person-search placeholder="Найти по имени…"></label><div class="sf-people-grid" data-sf-people>'+world.people.map((name,i)=>'<button type="button" class="sf-person" data-sf-action="person" data-name="'+esc(name)+'"><span class="sf-avatar sf-av-'+i+'">'+esc(name.split(' ').map(x=>x[0]).slice(0,2).join(''))+'</span><span>'+esc(name)+'</span>'+icon('chevron-right')+'</button>').join('')+'</div><p class="ui-subtle" data-sf-no-people '+(world.people.length?'hidden':'')+'>Персонажи не найдены.</p>';
      if(section==='Отношения')return '<span class="sf-kicker">НАПРАВЛЕННЫЕ ОТНОШЕНИЯ</span><h3>Связи персонажей</h3><p class="sf-description">Чувства и оценки направлены от одного персонажа к другому. Обратное отношение может отличаться.</p><div class="sf-info-card">'+icon('heart')+'<div><strong>'+esc(santa?'Илья → Мёрфи':(world.people[0]||'Персонаж')+' → '+(world.people[1]||'Другой персонаж'))+'</strong><p>'+esc(santa?'Отец и дочь. Семейная связь показана отдельно от оценок отношений.':'Взаимодействуют в текущей сцене. Числовые оценки в демо не заданы.')+'</p></div></div><p class="ui-subtle">'+chip+' Значения доверия и чувств здесь не выдумываются. В продукте они берутся из состояния прохождения.</p>'+button(icon('users')+'К персонажам','section','data-value="Персонажи"');
      if(section==='Сюжет')return '<span class="sf-kicker">СЮЖЕТНЫЕ ЛИНИИ</span><h3>Что развивается сейчас</h3><p class="ui-subtle">'+chip+' Примеры записей инспектора.</p>'+sampleEvents.filter(x=>x.kind==='thread').map(x=>'<article class="sf-record '+(highlight===x.id?'sf-record-highlight':'')+'"><span class="sf-tag">Развивается</span><h4>'+x.title+'</h4><p>'+x.text+'</p><small>Демонстрационная запись · не данные сохранения</small></article>').join('');
      if(section==='Тайны')return '<span class="sf-kicker">ЗНАНИЯ И ТАЙНЫ</span><h3>Известно персонажу</h3><p class="sf-description">Факты, знания и подозрения показаны раздельно. Демо-примеры для проверки переходов из уведомлений.</p>'+sampleEvents.filter(x=>x.kind==='secret').map(x=>'<article class="sf-record '+(highlight===x.id?'sf-record-highlight':'')+'"><span class="sf-tag">'+(x.id==='secret-notebook'?'Содержание неизвестно':'Известно Илье')+'</span><h4>'+x.title+'</h4><p>'+x.text+'</p><small>Демонстрационная запись</small></article>').join('');
      if(section==='Память')return '<span class="sf-kicker">ПАМЯТЬ ПРОХОЖДЕНИЯ</span><h3>События, факты и знания</h3><div class="sf-record"><small>Текущая сцена · '+chip+'</small><h4>'+esc(scene)+'</h4><p>'+esc(santa?'Соня записала шутливое признание Ильи. Мёрфи предложено вынести приговор.':world.summary)+'</p></div><div class="sf-info-card">'+icon('eye')+'<div><strong>Знания персонажа</strong><p>Просмотр сведений игроком сам по себе не передаёт знания персонажу.</p></div></div>';
      if(section==='Родословная')return '<span class="sf-kicker">СЕМЬЯ</span><h3>Родственные связи</h3>'+(santa?'<div class="sf-family-row"><span class="sf-avatar">ИВ</span><strong>Илья Волков</strong><span class="sf-family-link">Отец '+icon('arrow-right')+'</span><span class="sf-avatar sf-av-1">МВ</span><strong>Мёрфи Волкова</strong></div><p class="ui-subtle">'+chip+' Пример одной семейной связи в интерфейсе.</p>':'<p class="sf-description">Родственные связи в этом демонстрационном мире не заданы.</p>')+button(icon('users')+'К персонажам','section','data-value="Персонажи"');
      return '<span class="sf-kicker">НАСТРОЙКИ И СВЕДЕНИЯ О МИРЕ</span><h3>'+esc(world.name)+'</h3><div class="sf-facts"><div><small>Основа</small><strong>v1 · демонстрационная</strong></div><div><small>Прохождение</small><strong>'+esc(ui.state.saveName)+'</strong></div></div><h4>Правила повествования / стиль</h4><p class="sf-description">Живые диалоги, последовательные последствия, самостоятельные NPC. Управляемый персонаж действует по вводу игрока.</p><div class="sf-inline-actions">'+button(icon('file-text')+'Исходная выжимка','source')+button(icon('palette')+'Оформление','appearance')+'</div>';
    }
    function renderInspector(section,world=currentWorld(),baseline=false,highlight='') {
      if(!world){renderWorlds();return;}
      section=sectionAliases[section]||section||worldSection;
      if(!inspectorSections.some(([name])=>name===section))section='Мир';
      worldSection=section;
      const html='<div class="sf-inspector"><nav class="sf-inspector-nav" aria-label="Разделы инспектора">'+inspectorSections.map(([name,ic])=>'<button type="button" data-sf-action="section" data-value="'+name+'" aria-current="'+(!baseline&&section===name?'page':'false')+'">'+icon(ic)+name+'</button>').join('')+'</nav><div class="sf-inspector-content">'+inspectorContent(section,world,baseline,highlight)+'</div></div>';
      const body=modal(baseline?'Исходный мир':'О мире',baseline?world.name:world.name+' · '+(world.id===ui.state.worldId?ui.state.saveName:'Записи мира'),html,true,'inspector');
      wire(body,{'section':b=>renderInspector(b.dataset.value,world),'worlds':renderWorlds,'calendar':()=>ui.open('calendar'),'source':()=>renderInspector('Мир',world,true),'appearance':()=>renderSettings('appearance'),'person':b=>{if(world.id==='santa'){ui.close();ui.profile(b.dataset.name.split(' ')[0]);}else renderDemoPerson(b.dataset.name,world);}});
      body.querySelector('[data-sf-person-search]')?.addEventListener('input',event=>{const q=event.target.value.toLocaleLowerCase();let count=0;body.querySelectorAll('.sf-person').forEach(el=>{el.hidden=!el.dataset.name.toLocaleLowerCase().includes(q);if(!el.hidden)count++;});body.querySelector('[data-sf-no-people]').hidden=!!count;});
      body.querySelector('.sf-record-highlight')?.scrollIntoView({block:'nearest'});
    }
    function renderDemoPerson(name,world) {
      const body=modal(name,'Персонаж · '+world.name,'<div class="sf-info-card"><span class="sf-avatar">'+esc(name[0])+'</span><div><strong>'+esc(name)+'</strong><p>Участник текущей демонстрационной сцены.</p></div></div><div class="sf-facts"><div><small>Место</small><strong>'+esc(world.location)+'</strong></div></div>'+button(icon('arrow-left')+'К персонажам','back'),false);wire(body,{'back':()=>renderInspector('Персонажи',world)});
    }
    function renderEvents() {
      const list=showEventSamples?sampleEvents.filter(e=>eventFilter==='all'||e.kind===eventFilter):[];
      const html='<div class="sf-topline"><p class="ui-subtle">Открытия сохраняются в текущем прохождении.</p></div>'+tabs([['all','Все'],['thread','Сюжет'],['secret','Тайны']],eventFilter,'filter','Тип событий')+(showEventSamples?'<p class="sf-sample-note">Показаны примеры уведомлений для проверки интерфейса.</p><div class="sf-event-list">'+list.map(e=>'<button type="button" class="sf-event" data-sf-action="event" data-id="'+e.id+'"><span class="sf-event-icon">'+icon(e.icon)+'</span><span class="sf-event-copy"><small>'+e.label+' · Ход '+e.turn+'</small><strong>'+e.title+'</strong><span>'+e.text+'</span><em>Открыть запись '+icon('arrow-up-right')+'</em></span></button>').join('')+'</div><div class="sf-inline-actions">'+button('Скрыть примеры','hide-samples')+'</div>':'<div class="sf-empty">'+icon('bell')+'<h3>Открытий пока нет</h3><p>Здесь сохранятся новые сюжетные линии и подтверждённые тайны, доступные твоему персонажу.</p>'+button('Показать примеры открытий','samples')+'</div>');
      const body=modal('События истории','Новые сюжетные линии и известные твоему персонажу тайны.',html,false,'inspector');
      wire(body,{'filter':b=>{eventFilter=b.dataset.value;renderEvents();},'samples':()=>{showEventSamples=true;renderEvents();},'hide-samples':()=>{showEventSamples=false;renderEvents();},'event':b=>{const item=sampleEvents.find(e=>e.id===b.dataset.id);renderInspector(item.section,getWorld('santa'),false,item.id);}});
    }
    ui.register('worlds',renderWorlds);
    ui.register('create-world',renderCreator);
    ui.register('chat',()=>activeChat?renderChat():renderChatLibrary());
    ui.register('chat-campaigns',renderChatLibrary);
    ui.register('settings',tab=>renderSettings(typeof tab==='string'?tab:'models'));
    ui.register('world',section=>renderInspector(section));
    ui.register('events',renderEvents);
    root.addEventListener('nr:appearance-change',event=>{Object.assign(prefs,event.detail);applyAppearance();});
    root.addEventListener('click',event=>{if(!prefs.links&&event.target.closest('.nr-inlineperson')){event.preventDefault();event.stopImmediatePropagation();}},true);
    applyAppearance();
  };
})();

(function(){
  'use strict';
  const root=document.getElementById('nr-app');if(!root)return;
  const q=s=>root.querySelector(s),registry=new Map();
  const layer=q('[data-modal-layer]'),modal=q('.nr-modal');let body=q('[data-modal-body]');
  let previousFocus=null,heldInert=[],hooks={};
  const state={worldId:'santa',worldName:'Санта-Роса: вечер в кругу друзей',saveId:'santa-main',saveName:'Новое прохождение',location:'Семейная квартира Волковых',actor:'Илья',protagonist:'Илья',observedActor:null,observer:false,minutes:1208,dayOffset:0,notices:true};
  const names={'Илья':'Илья Волков','Соня':'Соня Величкина','Тимур':'Тимур Савельев','Катя':'Катя Соколова','Мёрфи':'Мёрфи Волкова'};
  function iconRefresh(){if(window.lucide)window.lucide.createIcons({attrs:{width:16,height:16}});root.querySelectorAll('button').forEach(b=>b.classList.add('cursor-interaction'));}
  function update(patch){Object.assign(state,patch);root.dispatchEvent(new CustomEvent('nr:state-change',{detail:{...state}}));if(hooks.refresh)hooks.refresh();}
  function close(){
    if(layer.hidden)return;
    layer.hidden=true;heldInert.forEach(([el,inert])=>el.inert=inert);heldInert=[];
    let returnTarget=previousFocus;
    if(returnTarget?.closest('.nr-sidebar')&&!root.classList.contains('nr-navopen')&&(root.clientWidth||1024)<=680)returnTarget=q('[data-toggle-nav]');
    const visible=el=>{if(!el?.isConnected||el.closest('[inert],[hidden]'))return false;const css=window.getComputedStyle?.(el);return !css||(css.display!=='none'&&css.visibility!=='hidden');};
    if(!visible(returnTarget))returnTarget=visible(q('[data-toggle-nav]'))?q('[data-toggle-nav]'):q('.nr-worldpicker');
    if(visible(returnTarget))returnTarget.focus({preventScroll:true});
    previousFocus=null;
  }
  function showModal(options){
    const wasHidden=layer.hidden;
    if(wasHidden){previousFocus=document.activeElement;root.dispatchEvent(new CustomEvent('nr:modal-will-open'));heldInert=[];for(const el of [...q('.nr-stage').children,q('.nr-sidebar')])if(el!==layer){heldInert.push([el,el.inert]);el.inert=true;}}
    q('#nr-modal-title').textContent=options.title||'';q('#nr-modal-description').textContent=options.subtitle||'';
    modal.dataset.size=options.size||'normal';modal.dataset.kind=options.kind||'confirm';layer.dataset.kind=modal.dataset.kind;const replacement=document.createElement('div');replacement.className='nr-modal-body';replacement.setAttribute('data-modal-body','');replacement.innerHTML=options.html||'';body.replaceWith(replacement);body=replacement;body.scrollTop=0;layer.hidden=false;
    layer.inert=false;iconRefresh();q('[data-close-modal]').focus({preventScroll:true});return body;
  }
  const ui={
    state,names,register(name,fn){registry.set(name,fn);},
    open(name,...args){const fn=registry.get(name);if(fn)return fn(...args);if(hooks.notice)hooks.notice('Этот раздел не входит в текущий концепт.');},
    modal:showModal,close,icons:iconRefresh,update,
    notice(text){if(hooks.notice)hooks.notice(text);},
    profile(name){close();if(hooks.profile)hooks.profile(name);},
    advance(minutes,kind){close();if(hooks.advance)return hooks.advance(minutes,kind);},
    control(name){close();update({actor:name,observer:false,observedActor:null});},
    observe(name){close();update({actor:null,observer:true,observedActor:name});if(hooks.observe)hooks.observe(name);},
    switchCampaign(value){close();if(hooks.switchCampaign)hooks.switchCampaign(value);else update(value);},
    getDraft(){return q('#nr-action').value;},
    bind(value){hooks={...hooks,...value};},
    reset(){if(hooks.reset)hooks.reset();},
    isModalOpen(){return !layer.hidden;}
  };
  root.__nrUI=ui;
  root.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;if(b.hasAttribute('data-ui'))ui.open(b.dataset.ui,b.dataset.section||undefined);if(b.hasAttribute('data-close-modal'))close();if(b.hasAttribute('data-concept-game'))close();});
  layer.addEventListener('click',e=>{if(e.target===layer)close();});
  layer.addEventListener('keydown',e=>{
    if(e.key==='Escape'){e.preventDefault();e.stopPropagation();close();return;}
    if(e.key!=='Tab')return;
    const controls=Array.from(modal.querySelectorAll('button:not(:disabled),input:not(:disabled),textarea:not(:disabled),select:not(:disabled),a[href]')).filter(el=>!el.closest('[hidden],[inert]')&&el.getClientRects().length);
    const first=controls[0],last=controls[controls.length-1];if(!first)return;
    if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
  });
  root.addEventListener('nr:state-change',()=>{
    const world=q('[data-current-world]'),save=q('[data-current-save]');if(world)world.textContent=state.worldName;if(save)save.textContent=state.saveName;
    const title=q('[data-current-location]');if(title)title.textContent=state.location;
    const side=q('.nr-campaign strong');if(side)side.textContent=state.worldName;
    const sub=q('.nr-campaign>span');if(sub)sub.textContent=state.saveName+' · Основа v1';
  });
})();

/* Narrative management concept. Local UI only; no API or model calls.
 * Sources: master 2597f1a3656296c6de945ceb425fda3c2cce1373:
 * frontend/src/{CurrentGame,WorldCamera,TimeSkip,LongTermAdvance,
 * NarrativePolicy,NarrativeDetail,Protagonist,WeatherSettings,GameCalendar}.tsx.
 * Main character, controlled character and observed character are separate.
 */
(function () {
  'use strict';

  window.installNarrativeManagement = function (root, ui) {
    let people = [
      {name:'Илья',full:'Илья Волков',initials:'ИВ',tone:'gold'},
      {name:'Соня',full:'Соня Величкина',initials:'СВ',tone:'rose'},
      {name:'Тимур',full:'Тимур Савельев',initials:'ТС',tone:'blue'},
      {name:'Катя',full:'Катя Соколова',initials:'КС',tone:'green'},
      {name:'Мёрфи',full:'Мёрфи Волкова',initials:'МВ',tone:'lilac'}
    ];
    const genres = [['slice_of_life','Повседневность'],['family_saga','Семейная сага'],['romance','Романтика'],['drama','Драма'],['detective','Детектив'],['thriller','Триллер'],['science_fiction','Научная фантастика'],['fantasy','Фэнтези'],['horror','Ужасы'],['adventure','Приключения'],['post_apocalyptic','Постапокалипсис'],['historical','Исторический'],['psychological_drama','Психологическая драма'],['political_drama','Политическая драма'],['crime_drama','Криминальная драма'],['space_opera','Космическая опера'],['dystopia','Антиутопия'],['alternate_history','Альтернативная история'],['cyberpunk','Киберпанк'],['dark_fantasy','Тёмное фэнтези'],['urban_fantasy','Городское фэнтези'],['epic_fantasy','Эпическое фэнтези'],['mysticism','Мистика'],['gothic','Готика'],['supernatural_thriller','Сверхъестественный триллер'],['dynastic_saga','Династическая сага'],['court_intrigue','Придворные интриги'],['war_drama','Военная драма'],['music_drama','Музыкальная драма'],['sports_drama','Спортивная драма'],['business_drama','Бизнес-драма'],['comedy','Комедия'],['satire','Сатира'],['black_comedy','Чёрная комедия'],['survival','Выживание'],['exploration','Исследование'],['nautical_adventure','Морские приключения'],['custom','Свой жанр']];
    const paceNames = {calm:'Спокойная',moderate:'Умеренная',dynamic:'Динамичная',intense:'Интенсивная',custom:'Свои настройки'};
    const riskNames = {safe:'Безопасный',realistic:'Реалистичный',harsh:'Суровый',unrestricted:'Без ограничений',custom:'Свои настройки'};
    const pacePresets = {
      calm:{intensity:.2,quiet_minutes:1440,pressure_limit:1,disruption:.1,escalation:.2,thread_cap:2,candidate_budget:1,relevance_floor:.8},
      moderate:{intensity:.45,quiet_minutes:360,pressure_limit:1.5,disruption:.3,escalation:.4,thread_cap:4,candidate_budget:2,relevance_floor:.6},
      dynamic:{intensity:.7,quiet_minutes:120,pressure_limit:2,disruption:.55,escalation:.65,thread_cap:6,candidate_budget:3,relevance_floor:.4},
      intense:{intensity:.9,quiet_minutes:60,pressure_limit:2.5,disruption:.75,escalation:.85,thread_cap:8,candidate_budget:4,relevance_floor:.25}
    };
    const paceBounds={intensity:[0,1],quiet_minutes:[0,43200],pressure_limit:[.1,4],disruption:[0,1],escalation:[0,1],thread_cap:[1,12],candidate_budget:[0,6],relevance_floor:[0,1]};
    const riskKeys=['minor_illness','serious_illness','injury','permanent_injury','relationship_loss','career_loss','life_role_loss','major_accident','npc_death','protagonist_death'];
    const riskPreset = preset => Object.fromEntries(riskKeys.map(k=>[k,preset==='safe'?k==='minor_illness':preset==='realistic'?!['permanent_injury','protagonist_death'].includes(k):preset==='harsh'?k!=='protagonist_death':true]));
    const stores = new Map();
    let gameTab = 'time';
    let cameraTab = 'characters';
    let cameraKnowledge = 'player';
    let chronologyActor = '';
    let selectedRecord = 0;
    let calendarMonth = null;
    let calendarSelected = null;
    let calendarYear = false;
    let peopleWorld = '';
    function syncPeople() {
      if(Array.isArray(ui.state.people)&&ui.state.people.length)people=ui.state.people.map(p=>({name:p.name,full:p.full||p.name,initials:p.initials||String(p.name).slice(0,2),tone:p.tone||'gold'}));
      if(peopleWorld!==ui.state.worldName){peopleWorld=ui.state.worldName;chronologyActor='';calendarMonth=null;calendarSelected=null;calendarYear=false;}
    }
    root.addEventListener('nr:state-change',syncPeople);
    syncPeople();
    const isSanta = () => ui.state.worldId==='santa'||ui.state.worldKey==='santa'||String(ui.state.worldName).includes('Санта-Роса');
    const location = () => ui.state.location || (isSanta()?'Семейная квартира Волковых':'Место не задано');
    const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    const icon = name => '<i data-lucide="'+name+'" aria-hidden="true"></i>';
    const person = name => people.find(p => p.name === name) || {name:name||'Персонаж',full:name||'Персонаж',initials:String(name||'П').slice(0,2),tone:'gold'};
    const avatar = name => {const p=person(name);return '<span class="gm-avatar gm-tone-'+p.tone+'" aria-hidden="true">'+esc(p.initials)+'</span>';};
    const now = () => (Number(ui.state.dayOffset)||0)*1440+(Number(ui.state.minutes)||0);
    const dateAt = minute => new Date(Date.UTC(2026,6,10,0,Math.round(minute)));
    const dateLabel = minute => dateAt(minute).toLocaleDateString('ru-RU',{day:'numeric',month:'long',year:'numeric',timeZone:'UTC'});
    const weekdayLabel = minute => dateAt(minute).toLocaleDateString('ru-RU',{weekday:'long',timeZone:'UTC'});
    const clock = minute => dateAt(minute).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit',timeZone:'UTC'});
    const iso = date => date.toISOString().slice(0,10);
    const durationLabel = n => Math.floor(n/60)+' ч '+n%60+' мин';
    const options = (entries,selected) => entries.map(([value,label])=>'<option value="'+esc(value)+'"'+(value===selected?' selected':'')+'>'+esc(label)+'</option>').join('');
    const field = (label,content,help='') => '<label class="ui-field gm-field"><span>'+label+'</span>'+content+(help?'<small>'+help+'</small>':'')+'</label>';
    const back = () => '<button type="button" class="gm-back" data-gm-back>'+icon('arrow-left')+'Управление игрой</button>';
    function store() {
      const key=ui.state.worldName+'::'+ui.state.saveName;
      if(!stores.has(key))stores.set(key,{weather:null,policy:{detail:'balanced',pace:'moderate',risk:'realistic',outcome:'natural',genre:isSanta()?'slice_of_life':'',secondary:isSanta()?['comedy']:[],custom:'',customPace:{...pacePresets.moderate},customRisk:riskPreset('realistic')},heroHistory:[]});
      return stores.get(key);
    }
    function mount(title,subtitle,html,size='normal',kind='game') {
      const body=ui.modal({title,subtitle,html:'<div class="gm-root">'+html+'</div>',size,kind});
      const parent=body.querySelector('[data-gm-back]');
      if(parent)parent.addEventListener('click',()=>game(gameTab));
      body.querySelectorAll('.gm-tabs[role="tablist"]').forEach(list=>{
        const buttons=Array.from(list.querySelectorAll('[role="tab"]'));
        buttons.forEach(b=>b.tabIndex=b.getAttribute('aria-selected')==='true'?0:-1);
        list.addEventListener('keydown',e=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;const at=buttons.indexOf(e.target);if(at<0)return;e.preventDefault();const next=e.key==='Home'?0:e.key==='End'?buttons.length-1:(at+(e.key==='ArrowRight'?1:-1)+buttons.length)%buttons.length;buttons[next].click();root.querySelector('.gm-tabs [role="tab"][aria-selected="true"]')?.focus();});
      });
      ui.icons();
      return body;
    }
    function finishAdvance(minutes,kind) {
      ui.close();
      ui.advance(minutes,kind);
    }
    function tabs(items,current) {
      return '<div class="ui-tabs gm-tabs" role="tablist">'+items.map(([id,label,ico])=>'<button type="button" role="tab" aria-selected="'+(current===id)+'" aria-controls="gm-active-panel" id="gm-tab-'+id+'" data-gm-tab="'+id+'">'+icon(ico)+'<span>'+label+'</span></button>').join('')+'</div>';
    }
    function timeView() {
      return '<div class="gm-clock-card"><div><span class="gm-eyebrow">ВРЕМЯ В МИРЕ</span><strong>'+clock(now())+'</strong><p>'+esc(weekdayLabel(now()))+', '+dateLabel(now())+'</p></div><span class="gm-clock-symbol">'+icon('sunset')+'</span><div class="gm-location">'+icon('map-pin')+esc(location())+'</div></div>'+
        '<div class="gm-quickgrid"><button type="button" class="gm-quickcard" data-gm-open="time-skip"><span class="gm-cardicon">'+icon('clock-3')+'</span><strong>Пропустить время</strong><p>Минуты, часы или несколько дней. Важное событие может прервать ожидание.</p><span class="gm-cardfoot">Выбрать время '+icon('arrow-up-right')+'</span></button><button type="button" class="gm-quickcard" data-gm-open="long-term"><span class="gm-cardicon">'+icon('hourglass')+'</span><strong>Длительный переход</strong><p>Недели, месяцы или годы. Обязательства и решения героя учитываются отдельно.</p><span class="gm-cardfoot">Настроить переход '+icon('arrow-up-right')+'</span></button></div>'+
        '<button type="button" class="gm-inline-link" data-gm-open="calendar">'+icon('calendar-days')+'Открыть календарь'+icon('arrow-right')+'</button>';
    }
    function charactersView() {
      return '<div class="gm-mainactor">'+avatar(ui.state.protagonist)+'<div><span class="gm-eyebrow">ГЛАВНЫЙ ГЕРОЙ</span><strong>'+esc(person(ui.state.protagonist).full)+'</strong><p>Смена главного героя сохраняет мир и время.</p></div><button type="button" class="ui-button" data-gm-open="protagonist">Сменить</button></div>'+
        '<button type="button" class="gm-camera-link" data-gm-open="camera">'+icon('scan-eye')+'<span><strong>Наблюдение и временное управление</strong><small>Перейти к другому персонажу или посмотреть на его сцену</small></span>'+icon('chevron-right')+'</button>'+
        '<div class="gm-listhead"><h3>Персонажи <span>'+people.length+'</span></h3><label class="gm-search">'+icon('search')+'<input type="search" data-gm-search aria-label="Найти персонажа" placeholder="Найти по имени"></label></div><div class="gm-people-list" data-gm-people>'+peopleRows('')+'</div>';
    }
    function peopleRows(query) {
      const filtered=people.filter(p=>p.full.toLocaleLowerCase().includes(query.toLocaleLowerCase()));
      return filtered.length?filtered.map(p=>'<button type="button" class="gm-personrow" data-gm-profile="'+esc(p.name)+'">'+avatar(p.name)+'<span><strong>'+esc(p.full)+'</strong><small>'+(ui.state.actor===p.name&&!ui.state.observer?'Сейчас под вашим управлением':ui.state.protagonist===p.name?'Главный герой':'В текущей сцене')+'</small></span>'+icon('chevron-right')+'</button>').join(''):'<p class="gm-empty">По этому имени никого не найдено.</p>';
    }
    const records=[
      {time:'20:08',title:'Мёрфи получает последнее слово',text:'Соня записывает шутливое признание Ильи и передаёт Мёрфи право вынести окончательный приговор.',people:['Илья','Мёрфи','Соня'],copy:'— Записала, — подтверждает Соня, не поднимая глаз. — «Ответчик признал поражение, ссылаясь на возраст. Дело передано Мёрфи для вынесения окончательного приговора».\n\nМёрфи тут же выпрямляется, чувствуя вес вручённой ей власти, и обводит взрослых взглядом судьи, у которого в кармане завалялась лупа.'},
      {time:'20:06',title:'Шутливое разбирательство за столом',text:'После вопроса Сони о посуде Илья просит учесть свой возраст и тяжёлый рабочий день.',people:['Илья','Соня','Тимур'],copy:'Тимур ставит на стол блюдо и отодвигает локтем вазу. Мёрфи тут же придвигает к себе самую большую тарелку.\n\n— Так, — говорит Соня, щёлкая ручкой. — Кто обещал после ужина помыть посуду?\n\nИлья откидывается на спинку стула: «Требую учесть мой возраст и тяжёлый рабочий день».'},
      {time:'20:00',title:'Вечер в кругу друзей',text:'Все собираются за столом в семейной квартире Волковых.',people:['Илья','Соня','Тимур','Катя','Мёрфи'],copy:'Тёплый вечер в квартире Волковых. Илья, Соня, Тимур, Катя и Мёрфи собрались за одним столом.'}
    ];
    function recordRows(actor='',camera=false) {
      if(!isSanta())return '<div class="gm-empty">'+icon('history')+'<strong>Здесь пока нет записанных событий</strong><p>Хронология относится только к выбранному прохождению.</p></div>';
      return records.map((r,i)=>({r,i})).filter(({r})=>!actor||r.people.includes(actor)).map(({r,i})=>'<article class="gm-timeline-item"><time>'+r.time+'</time><div><strong>'+r.title+'</strong><p>'+r.text+'</p><button type="button" class="gm-inline-link" data-gm-record="'+i+'">'+icon(camera?'play':'eye')+'Посмотреть сцену</button></div></article>').join('') || '<p class="gm-empty">Нет доступных событий этого персонажа.</p>';
    }
    function chronologyView() {
      const history=store().heroHistory;
      return '<div class="gm-sectionintro"><h3>Хронология</h3><p>Известные события прохождения, от новых к ранним.</p></div><details class="gm-disclosure"><summary>История главных героев</summary><div class="gm-detailbody"><p>'+esc(person(ui.state.protagonist).full)+' · сейчас</p>'+history.map(p=>'<p>'+esc(person(p.name).full)+' · до '+esc(p.when)+'</p>').join('')+(!history.length?'<p class="ui-subtle">Главный герой ещё не менялся.</p>':'')+'</div></details>'+
        field('События персонажа','<select data-gm-chronology>'+options([['','Все доступные события'],...people.map(p=>[p.name,p.full])],chronologyActor)+'</select>')+
        (isSanta()?'<div class="gm-timeline-date">10 июля 2026</div>':'')+'<div class="gm-timeline" data-gm-timeline>'+recordRows(chronologyActor)+'</div>';
    }
    function settingsView() {
      const s=store();
      return '<button type="button" class="gm-camera-link" data-gm-open="policy">'+icon('sliders-horizontal')+'<span><strong>Политика истории</strong><small>'+paceNames[s.policy.pace]+' интенсивность · '+riskNames[s.policy.risk].toLocaleLowerCase()+' риск</small></span>'+icon('chevron-right')+'</button>'+
        '<label class="gm-switchrow"><span><strong>Игровые уведомления</strong><small>Новые линии сюжета, тайны и отношения. События сохраняются в журнале.</small></span><input type="checkbox" role="switch" data-gm-notices'+(ui.state.notices?' checked':'')+' aria-label="Показывать игровые уведомления"></label>'+
        '<details class="gm-disclosure"><summary>'+icon('radio')+'Технологии связи<span class="gm-readonly">Заданы миром</span></summary><div class="gm-detailbody"><div class="gm-channel-list"><span>'+icon('phone')+'Звонки</span><span>'+icon('message-square')+'SMS</span><span>'+icon('messages-square')+'Мессенджер</span></div><p>Личные разговоры доступны всегда. Каналы связи настраиваются до начала игры.</p></div></details>'+
        '<details class="gm-disclosure"><summary>'+icon('cloud-sun')+'Климат и погода<span class="gm-readonly">'+(s.weather?'Настроено':'Не задано')+'</span></summary><div class="gm-detailbody">'+(s.weather?'<p><strong>'+esc(s.weather.region)+' · '+esc(s.weather.climateLabel)+'</strong></p><p>Климат установлен. Погода следует времени и региону мира; просмотр календаря её не меняет.</p>':weatherForm())+'</div></details>';
    }
    function weatherForm() {
      return '<form data-gm-weather class="ui-stack gm-weather-form"><p>Задайте регион — погода появится с текущего игрового момента. Прошлое сохраняется.</p><div class="gm-formgrid">'+field('Регион','<select name="region" required><option value="">Выбрать место</option><option>'+esc(location())+'</option></select>')+field('Климат','<select name="climate">'+options([['temperate','Умеренный'],['tropical','Тропический'],['arid','Засушливый'],['polar','Полярный']],'temperate')+'</select>')+field('Полушарие','<select name="hemisphere">'+options([['','Не задано'],['north','Северное'],['south','Южное']],'north')+'</select>')+field('Температура','<select name="unit"><option value="C">°C</option><option value="F">°F</option></select>')+'</div><button class="ui-button primary" type="submit">Установить климат</button></form>';
    }
    function game(tab=gameTab) {
      gameTab=tab;
      const body=mount('Управление игрой',esc(ui.state.saveName)+' · '+esc(ui.state.worldName),tabs([['time','Время','clock-3'],['characters','Персонажи','users'],['chronology','Хронология','history'],['settings','Настройки','sliders-horizontal']],tab)+'<section class="gm-tabpanel" id="gm-active-panel" role="tabpanel" aria-labelledby="gm-tab-'+tab+'">'+({time:timeView,characters:charactersView,chronology:chronologyView,settings:settingsView}[tab])()+'</section>','wide');
      body.addEventListener('click',e=>{
        const b=e.target.closest('button');if(!b)return;
        if(b.dataset.gmTab){game(b.dataset.gmTab);return;}
        if(b.dataset.gmOpen){ui.open(b.dataset.gmOpen);return;}
        if(b.dataset.gmProfile){ui.profile(b.dataset.gmProfile);return;}
        if(b.hasAttribute('data-gm-record'))recordedScene(Number(b.dataset.gmRecord),()=>game('chronology'));
      });
      const search=body.querySelector('[data-gm-search]');
      if(search)search.addEventListener('input',()=>{body.querySelector('[data-gm-people]').innerHTML=peopleRows(search.value);ui.icons();});
      const chronology=body.querySelector('[data-gm-chronology]');
      if(chronology)chronology.addEventListener('change',()=>{chronologyActor=chronology.value;body.querySelector('[data-gm-timeline]').innerHTML=recordRows(chronologyActor);ui.icons();});
      const notices=body.querySelector('[data-gm-notices]');
      if(notices)notices.addEventListener('change',()=>{ui.update({notices:notices.checked});ui.notice(notices.checked?'Игровые уведомления включены':'Игровые уведомления выключены. Журнал сохраняется.');});
      const weather=body.querySelector('[data-gm-weather]');
      if(weather)weather.addEventListener('submit',e=>{e.preventDefault();if(!weather.reportValidity())return;const data=new FormData(weather);store().weather={region:data.get('region'),climate:data.get('climate'),climateLabel:weather.elements.climate.selectedOptions[0].textContent,hemisphere:data.get('hemisphere'),unit:data.get('unit')};game('settings');ui.notice('Климат задан для демонстрационного прохождения.');});
    }
    function camera(tab=cameraTab) {
      cameraTab=tab;
      const actor=ui.state.actor;
      const body=mount('Камера мира','Наблюдение и управление — разные действия.',tabs([['characters','Персонажи и сцены','scan-eye'],['journal','Журнал событий','history']],tab)+'<section class="gm-tabpanel" id="gm-active-panel" role="tabpanel" aria-labelledby="gm-tab-'+tab+'">'+(tab==='characters'?'<div class="gm-camera-state">'+icon(ui.state.observer?'eye':'user-round')+'<span>'+(ui.state.observer?'Наблюдение: '+esc(person(ui.state.observedActor).full):'Под управлением: '+esc(person(actor).full))+'</span></div><div class="gm-camera-grid">'+people.map(p=>'<article class="gm-camera-person"><div class="gm-camera-personhead">'+avatar(p.name)+'<div><strong>'+esc(p.full)+'</strong><small>'+(p.name===ui.state.protagonist?'Главный герой':'Участник сцены')+'</small></div></div><p class="gm-camera-location">'+icon('map-pin')+esc(location())+'</p><div class="gm-camera-actions"><button type="button" class="ui-button" data-gm-observe="'+esc(p.name)+'"'+(ui.state.observer&&ui.state.observedActor===p.name?' disabled':'')+'>'+icon('eye')+'Наблюдать</button><button type="button" class="ui-button" data-gm-control="'+esc(p.name)+'"'+(!ui.state.observer&&actor===p.name?' disabled':'')+'>'+icon('user-round')+'Временно управлять</button></div></article>').join('')+'</div>':field('Видимость событий','<select data-gm-knowledge>'+options([['player','Известно игроку'],['actor','Известно текущему персонажу']],cameraKnowledge)+'</select>')+'<div data-gm-journal>'+cameraJournal()+'</div>')+'</section>','wide');
      body.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;if(b.dataset.gmTab){camera(b.dataset.gmTab);return;}if(b.dataset.gmObserve){ui.close();ui.observe(b.dataset.gmObserve);return;}if(b.dataset.gmControl){ui.close();ui.control(b.dataset.gmControl);return;}if(b.hasAttribute('data-gm-record'))recordedScene(Number(b.dataset.gmRecord),()=>camera('journal'));});
      const knowledge=body.querySelector('[data-gm-knowledge]');if(knowledge)knowledge.addEventListener('change',()=>{cameraKnowledge=knowledge.value;body.querySelector('[data-gm-journal]').innerHTML=cameraJournal();ui.icons();});
    }
    function cameraJournal() {
      if(cameraKnowledge==='actor'&&ui.state.observer)return '<div class="gm-empty">'+icon('eye')+'<strong>Выберите управляемого персонажа</strong><p>В режиме наблюдения нет персонажа, чьи знания можно открыть.</p><button type="button" class="ui-button" data-gm-tab="characters">К персонажам</button></div>';
      return '<p class="gm-journalhint">Записи прошлого доступны для просмотра. Открытие записи не меняет время и состояние мира.</p>'+(isSanta()?'<div class="gm-timeline-date">10 июля 2026</div>':'')+'<div class="gm-timeline">'+recordRows(cameraKnowledge==='actor'?ui.state.actor:'',true)+'</div>';
    }
    function recordedScene(index,returnTo) {
      if(!isSanta()){camera('journal');return;}
      selectedRecord=index;
      const r=records[selectedRecord]||records[0];
      const body=mount('Записанная сцена','Просмотр прошлого. Состояние игры и время не меняются.','<button type="button" class="gm-back" data-gm-record-back>'+icon('arrow-left')+'К журналу</button><div class="gm-record-meta"><span>'+icon('clock-3')+'10 июля 2026 · '+r.time+'</span><span>'+icon('map-pin')+'Квартира Волковых</span></div><h3 class="gm-record-title">'+r.title+'</h3><div class="gm-record-prose">'+r.copy.split('\n\n').map(p=>'<p>'+esc(p)+'</p>').join('')+'</div><div class="gm-record-people">'+r.people.map(n=>'<button type="button" class="gm-personchip" data-gm-record-person="'+n+'">'+avatar(n)+esc(n)+'</button>').join('')+'</div>','wide');
      body.querySelector('[data-gm-record-back]').addEventListener('click',returnTo);
      body.querySelectorAll('[data-gm-record-person]').forEach(b=>b.addEventListener('click',()=>ui.profile(b.dataset.gmRecordPerson)));
    }
    function timeSkip() {
      let duration=60;
      const started=now();
      const body=mount('Пропустить время','Мир продолжит жить. Событие, требующее участия героя, может прервать ожидание.',back()+'<form data-gm-skip-form class="ui-stack"><div class="gm-time-transfer"><div><span>Сейчас</span><strong>'+clock(started)+'</strong><small>'+dateLabel(started)+'</small></div>'+icon('arrow-right')+'<div><span>После ожидания</span><strong data-gm-target-time></strong><small data-gm-target-date></small></div></div><div class="gm-duration-heading"><span>Длительность ожидания</span><strong data-gm-duration></strong></div><input type="range" class="gm-range" aria-label="Длительность пропуска времени" min="1" max="1440" value="60" data-gm-duration-range><div class="gm-presets"><button type="button" data-gm-preset="10">+10 мин</button><button type="button" data-gm-preset="60">+1 час</button><button type="button" data-gm-until="1080">До вечера</button><button type="button" data-gm-until="0">До полуночи</button><button type="button" data-gm-until="420">До утра</button></div><div class="gm-formgrid">'+field('Дней вперёд','<input type="number" min="0" max="7" step="1" value="0" data-gm-days>')+field('Конечное время','<input type="time" data-gm-end-time required>')+'</div>'+field('Причина <span class="gm-optional">Необязательно</span>','<input name="reason" maxlength="1000" placeholder="Например, дождаться утра">')+'<div class="gm-footer"><button type="button" class="ui-button" data-gm-cancel>Отмена</button><button class="ui-button primary" type="submit" data-gm-submit>Пропустить время</button></div></form>');
      const range=body.querySelector('[data-gm-duration-range]');
      const days=body.querySelector('[data-gm-days]');
      const time=body.querySelector('[data-gm-end-time]');
      function paint() {duration=Math.round(Math.max(1,Math.min(10080,duration)));const end=started+duration;body.querySelector('[data-gm-target-time]').textContent=clock(end);body.querySelector('[data-gm-target-date]').textContent=dateLabel(end);body.querySelector('[data-gm-duration]').textContent=durationLabel(duration);range.value=Math.min(duration,1440);days.value=Math.floor(end/1440)-Math.floor(started/1440);time.value=clock(end);body.querySelector('[data-gm-submit]').textContent='Пропустить '+durationLabel(duration);}
      range.addEventListener('input',()=>{duration=Number(range.value);paint();});
      days.addEventListener('change',()=>{const currentEnd=started+duration;duration=Number(days.value)*1440+(currentEnd%1440)-(started%1440);paint();});
      time.addEventListener('change',()=>{if(!time.value)return;const [h,m]=time.value.split(':').map(Number);duration=(Math.floor((started+duration)/1440)*1440+h*60+m)-started;if(duration<=0)duration+=1440;paint();});
      body.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;if(b.hasAttribute('data-gm-preset')){duration=Number(b.dataset.gmPreset);paint();}if(b.hasAttribute('data-gm-until')){const d=Number(b.dataset.gmUntil)-started%1440;duration=d>0?d:d+1440;paint();}if(b.hasAttribute('data-gm-cancel'))game('time');});
      body.querySelector('form').addEventListener('submit',e=>{e.preventDefault();if(!e.currentTarget.reportValidity())return;finishAdvance(duration,'time-skip');});
      paint();
    }
    function longTerm() {
      const started=now();
      const body=mount('Длительный переход','Мир проживёт выбранный интервал. Решения управляемого персонажа остаются за вами.',back()+'<form class="ui-stack" data-gm-long-form><div class="gm-formgrid">'+field('Интервал','<input type="number" name="amount" min="1" max="200" step="1" value="1" required aria-label="Количество единиц перехода">')+field('Единица','<select name="unit" aria-label="Единица перехода"><option value="weeks">Недели</option><option value="months">Месяцы</option><option value="years">Годы</option></select>')+'</div>'+field('Причина <span class="gm-optional">Необязательно</span>','<textarea name="reason" rows="3" maxlength="1000" placeholder="Почему проходит это время?"></textarea>')+'<details class="gm-disclosure"><summary>Подробности симуляции</summary><div class="gm-detailbody">'+field('Лимит обращений к модели','<input name="budget" type="number" min="0" max="8" step="1" value="4" required aria-label="Лимит обращений к модели">','Одна группа исходов требует двух обращений. При нулевом лимите выполняются только определённые переходы.')+'</div></details><div class="gm-time-transfer gm-long-transfer"><div><span>Сейчас</span><strong>'+dateLabel(started)+'</strong><small>'+clock(started)+'</small></div>'+icon('arrow-right')+'<div><span>Дата окончания</span><strong data-gm-long-destination></strong><small>Предпросмотр интервала</small></div></div><p class="gm-callout">'+icon('user-round-check')+'Переход может остановиться для вашего решения. Возможность не становится событием автоматически.</p><div class="gm-footer"><button type="button" class="ui-button" data-gm-cancel>Отмена</button><button type="submit" class="ui-button primary" data-gm-long-submit>Подтвердить переход</button></div></form>');
      const form=body.querySelector('form');
      let delta=0;
      function refresh() {
        const n=Number(form.elements.amount.value);const unit=form.elements.unit.value;const valid=Number.isInteger(n)&&n>=1&&n<=200&&form.elements.budget.validity.valid;
        const end=dateAt(started);
        if(unit==='weeks')end.setUTCDate(end.getUTCDate()+n*7);
        if(unit==='months'){const day=end.getUTCDate();end.setUTCDate(1);end.setUTCMonth(end.getUTCMonth()+n);const last=new Date(Date.UTC(end.getUTCFullYear(),end.getUTCMonth()+1,0)).getUTCDate();end.setUTCDate(Math.min(day,last));}
        if(unit==='years'){const month=end.getUTCMonth();end.setUTCFullYear(end.getUTCFullYear()+n);if(end.getUTCMonth()!==month)end.setUTCDate(0);}
        delta=Math.round((end-dateAt(started))/60000);
        body.querySelector('[data-gm-long-destination]').textContent=valid?dateLabel(started+delta):'Проверьте интервал';body.querySelector('[data-gm-long-submit]').disabled=!valid;
      }
      form.addEventListener('input',refresh);form.addEventListener('change',refresh);
      form.addEventListener('submit',e=>{e.preventDefault();if(!form.reportValidity())return;finishAdvance(delta,'long-term');});
      body.querySelector('[data-gm-cancel]').addEventListener('click',()=>game('time'));refresh();
    }
    function policy() {
      const draft=JSON.parse(JSON.stringify(store().policy));
      const details=[['brief','Кратко'],['balanced','Сбалансированно'],['detailed','Подробно'],['extended','Развёрнуто']];
      const riskFields=[['minor_illness','Лёгкие заболевания'],['serious_illness','Серьёзные заболевания'],['injury','Травмы'],['permanent_injury','Необратимые травмы'],['relationship_loss','Потеря отношений'],['career_loss','Потеря работы или учёбы'],['life_role_loss','Потеря жизненной роли или жилья'],['major_accident','Тяжёлые происшествия'],['npc_death','Смерть других персонажей'],['protagonist_death','Смерть главного героя']];
      const paceFields=[['intensity','Интенсивность'],['quiet_minutes','Затишье, минуты мира'],['pressure_limit','Предел давления'],['disruption','Внешние потрясения'],['escalation','Усиление осложнений'],['thread_cap','Активные линии'],['candidate_budget','Лимит предложений'],['relevance_floor','Минимальная релевантность']];
      const body=mount('Политика истории','Настройки влияют на будущие события. Прошлое сохраняется.',back()+'<form data-gm-policy class="ui-stack">'+field('Подробность повествования','<select name="detail">'+options(details,draft.detail)+'</select>','Определяет подробность описания текущего момента. Следующее решение остаётся за вами.')+'<div class="gm-formgrid">'+field('Интенсивность истории','<select name="pace">'+options(Object.entries(paceNames),draft.pace)+'</select>')+field('Риск последствий','<select name="risk">'+options(Object.entries(riskNames),draft.risk)+'</select>')+'</div><div class="gm-custompolicy" data-gm-custom-pace'+(draft.pace==='custom'?'':' hidden')+'><h3>Своя интенсивность</h3><div class="gm-formgrid">'+paceFields.map(([key,label])=>field(label,'<input type="number" name="pace_'+key+'" min="'+paceBounds[key][0]+'" max="'+paceBounds[key][1]+'" required step="'+(['quiet_minutes','thread_cap','candidate_budget'].includes(key)?'1':'.05')+'" value="'+draft.customPace[key]+'">')).join('')+'</div></div><div class="gm-custompolicy" data-gm-custom-risk'+(draft.risk==='custom'?'':' hidden')+'><h3>Свои последствия</h3><div class="gm-formgrid">'+riskFields.map(([key,label])=>'<label class="gm-risk-toggle"><span>'+label+'</span><input type="checkbox" name="risk_'+key+'"'+(draft.customRisk[key]?' checked':'')+'></label>').join('')+'</div></div><p class="gm-journalhint">Высокий риск разрешает тяжёлые последствия, но не требует их.</p>'+field('Исходы связанных с героем линий','<select name="outcome">'+options([['natural','Естественное развитие'],['prefer_happy','Предпочитать благоприятные исходы'],['guaranteed_happy_path','Сохранять достижимый благоприятный путь']],draft.outcome)+'</select>','Благоприятный путь — возможность, а не предрешённый финал.')+'<details class="gm-disclosure"><summary>'+icon('sparkles')+'Жанры истории<span class="gm-readonly" data-gm-genre-summary></span></summary><div class="gm-detailbody ui-stack">'+field('Основной жанр','<select name="genre">'+options([['','Из описания мира'],...genres],draft.genre)+'</select>')+'<div class="gm-secondary-head"><strong>Дополнительные оттенки</strong><span data-gm-secondary-count></span></div><div class="gm-genre-list">'+genres.map(([id,name])=>'<label class="gm-genre-option"><input type="checkbox" name="secondary" value="'+id+'"'+(draft.secondary.includes(id)?' checked':'')+'><span>'+name+'</span></label>').join('')+'</div><label class="ui-field gm-field" data-gm-custom-genre'+([draft.genre,...draft.secondary].includes('custom')?'':' hidden')+'><span>Описание своего жанра</span><textarea name="custom" rows="3" maxlength="2000">'+esc(draft.custom)+'</textarea></label><p class="gm-journalhint">Смена жанров влияет только на новые ходы. Перегенерация использует исходные настройки хода.</p></div></details><div class="gm-footer"><button type="button" class="ui-button" data-gm-cancel>Отмена</button><button type="submit" class="ui-button primary">Сохранить настройки истории</button></div></form>','wide');
      const form=body.querySelector('form');
      let previousPace=draft.pace,previousRisk=draft.risk;
      function sync() {
        if(form.elements.pace.value!==previousPace){const preset=pacePresets[form.elements.pace.value];if(preset)paceFields.forEach(([key])=>form.elements['pace_'+key].value=preset[key]);previousPace=form.elements.pace.value;}
        if(form.elements.risk.value!==previousRisk){if(form.elements.risk.value!=='custom'){const preset=riskPreset(form.elements.risk.value);riskFields.forEach(([key])=>form.elements['risk_'+key].checked=preset[key]);}previousRisk=form.elements.risk.value;}
        const selected=Array.from(form.querySelectorAll('[name="secondary"]:checked')).map(n=>n.value).filter(v=>v!==form.elements.genre.value);
        form.querySelectorAll('[name="secondary"]').forEach(c=>{if(c.value===form.elements.genre.value)c.checked=false;c.disabled=c.value===form.elements.genre.value||selected.length>=3&&!c.checked;});
        body.querySelector('[data-gm-secondary-count]').textContent=selected.length+' из 3';
        body.querySelector('[data-gm-genre-summary]').textContent=(genres.find(g=>g[0]===form.elements.genre.value)||['','Из мира'])[1];
        const custom=[form.elements.genre.value,...selected].includes('custom');body.querySelector('[data-gm-custom-genre]').hidden=!custom;form.elements.custom.required=custom;
        body.querySelector('[data-gm-custom-pace]').hidden=form.elements.pace.value!=='custom';body.querySelector('[data-gm-custom-risk]').hidden=form.elements.risk.value!=='custom';
      }
      form.addEventListener('change',sync);
      form.addEventListener('submit',e=>{e.preventDefault();if(!form.reportValidity())return;['detail','pace','risk','outcome','genre','custom'].forEach(k=>draft[k]=form.elements[k].value);draft.secondary=Array.from(form.querySelectorAll('[name="secondary"]:checked')).map(c=>c.value);paceFields.forEach(([k])=>draft.customPace[k]=Number(form.elements['pace_'+k].value));riskFields.forEach(([k])=>draft.customRisk[k]=form.elements['risk_'+k].checked);store().policy=draft;game('settings');ui.notice('Политика сохранена для следующих демонстрационных ходов.');});
      body.querySelector('[data-gm-cancel]').addEventListener('click',()=>game('settings'));sync();
    }
    function protagonist(path='existing',chosen='',preview=false) {
      const body=mount('Смена главного героя','Мир и время сохраняются. У каждого персонажа остаются собственные знания, личность и прошлое.',back()+'<div class="ui-tabs gm-tabs" role="tablist"><button type="button" role="tab" aria-selected="'+(path==='existing')+'" data-gm-path="existing">'+icon('users')+'Выбрать персонажа</button><button type="button" role="tab" aria-selected="'+(path==='create')+'" data-gm-path="create">'+icon('user-round-plus')+'Создать нового</button></div>'+(path==='existing'?'<div class="gm-protagonist-options">'+people.map(p=>'<label class="gm-protagonist-option"><input type="radio" name="gm-protagonist" value="'+esc(p.name)+'"'+(chosen===p.name?' checked':'')+'>'+avatar(p.name)+'<span><strong>'+esc(p.full)+'</strong><small>'+(p.name===ui.state.protagonist?'Сейчас главный герой':'Участник текущего мира')+'</small></span>'+icon('check')+'</label>').join('')+'</div>'+(preview?'<div class="gm-confirmation" role="status">'+icon('check-circle-2')+'<div><strong>Готово к подтверждению</strong><p>'+esc(person(chosen).full)+' станет главным героем. Время мира не изменится.</p></div></div>':'')+'<div class="gm-footer"><button type="button" class="ui-button" data-gm-cancel>Отмена</button><button type="button" class="ui-button primary" data-gm-confirm'+(!chosen||chosen===ui.state.protagonist?' disabled':'')+'>'+(preview?'Подтвердить смену':'Проверить и посмотреть')+'</button></div>':'<div class="gm-newcharacter ui-stack"><div class="gm-callout">'+icon('user-round-plus')+'<span>Создание нового героя открывает полный редактор персонажа. Карточка, связи и стартовая сцена проверяются перед добавлением в мир.</span></div>'+field('Пожелания для генерации','<textarea rows="4" placeholder="Опишите персонажа и его место в этом мире"></textarea>')+'<button type="button" class="ui-button" disabled>Создать полный черновик моделью</button><p class="gm-journalhint">В этом интерактивном концепте модель не подключена. Можно проверить смену героя на одного из существующих персонажей.</p><button type="button" class="gm-inline-link" data-gm-path="existing">Выбрать существующего героя '+icon('arrow-right')+'</button></div>'));
      let current=chosen;
      body.querySelectorAll('[data-gm-path]').forEach(b=>b.addEventListener('click',()=>protagonist(b.dataset.gmPath)));
      body.querySelectorAll('[name="gm-protagonist"]').forEach(r=>r.addEventListener('change',()=>{current=r.value;if(preview){protagonist('existing',current,false);return;}body.querySelector('[data-gm-confirm]').disabled=current===ui.state.protagonist;}));
      const confirm=body.querySelector('[data-gm-confirm]');if(confirm)confirm.addEventListener('click',()=>{if(!preview){protagonist('existing',current,true);return;}store().heroHistory.unshift({name:ui.state.protagonist,when:dateLabel(now())+' '+clock(now())});ui.update({protagonist:current});ui.close();ui.control(current);ui.notice(person(current).full+' — главный герой. Время мира сохранено.');});
      const cancel=body.querySelector('[data-gm-cancel]');if(cancel)cancel.addEventListener('click',()=>game('characters'));
    }
    function calendar() {
      const today=iso(dateAt(now()));
      if(!calendarMonth)calendarMonth=today.slice(0,7);
      if(!calendarSelected)calendarSelected=today;
      const y=Number(calendarMonth.slice(0,4)),m=Number(calendarMonth.slice(5))-1;
      const currentMonth=new Date(Date.UTC(y,m,1));
      const monthTitle=currentMonth.toLocaleDateString('ru-RU',{month:'long',year:'numeric',timeZone:'UTC'});
      let grid='';
      if(calendarYear)grid='<div class="gm-yeargrid">'+Array.from({length:12},(_,i)=>'<button type="button" data-gm-calendar-month="'+y+'-'+String(i+1).padStart(2,'0')+'"'+(i===m?' aria-current="date"':'')+'><strong>'+new Date(Date.UTC(y,i,1)).toLocaleDateString('ru-RU',{month:'long',timeZone:'UTC'})+'</strong><span>'+new Date(Date.UTC(y,i+1,0)).getUTCDate()+' дней</span></button>').join('')+'</div>';
      else {
        const lead=(currentMonth.getUTCDay()+6)%7,days=new Date(Date.UTC(y,m+1,0)).getUTCDate();
        grid='<div class="gm-weekdays">'+['Пн','Вт','Ср','Чт','Пт','Сб','Вс'].map(d=>'<span>'+d+'</span>').join('')+'</div><div class="gm-monthgrid">'+Array.from({length:lead},()=>'<span aria-hidden="true"></span>').join('')+Array.from({length:days},(_,i)=>{const value=calendarMonth+'-'+String(i+1).padStart(2,'0');const event=isSanta()&&value==='2026-07-10';return '<button type="button" data-gm-calendar-day="'+value+'" class="'+(value===today?'gm-is-today ':'')+(value===calendarSelected?'gm-is-selected':'')+'" aria-pressed="'+(value===calendarSelected)+'" aria-label="'+(i+1)+' '+monthTitle+(value===today?', сегодня в игре':'')+(event?', 3 события':'')+'"><span>'+(i+1)+'</span>'+(event?'<i class="gm-daydot" aria-hidden="true"></i>':'')+'</button>';}).join('')+'</div>';
      }
      const selectedDate=new Date(calendarSelected+'T12:00:00Z');
      const selectedTitle=selectedDate.toLocaleDateString('ru-RU',{day:'numeric',month:'long',year:'numeric',timeZone:'UTC'});
      const body=mount('Календарь','Сегодня в игре · '+dateLabel(now())+' · '+clock(now()),'<div class="gm-calendar-toolbar"><div class="gm-calendar-pager"><button type="button" class="gm-iconbutton" data-gm-month-step="-1" aria-label="Предыдущий '+(calendarYear?'год':'месяц')+'">'+icon('chevron-left')+'</button><strong>'+esc(calendarYear?String(y):monthTitle)+'</strong><button type="button" class="gm-iconbutton" data-gm-month-step="1" aria-label="Следующий '+(calendarYear?'год':'месяц')+'">'+icon('chevron-right')+'</button></div><div class="gm-calendar-modes"><button type="button" class="ui-button" data-gm-calendar-today>Сегодня</button><button type="button" data-gm-calendar-mode="month" aria-pressed="'+(!calendarYear)+'">Месяц</button><button type="button" data-gm-calendar-mode="year" aria-pressed="'+calendarYear+'">Год</button></div></div><div class="gm-calendar-layout"><div class="gm-calendar-grid">'+grid+'</div><section class="gm-calendar-detail"><span class="gm-eyebrow">'+(calendarSelected===today?'СЕГОДНЯ В ИГРЕ':'ВЫБРАННЫЙ ДЕНЬ')+'</span><h3>'+selectedTitle+'</h3>'+(isSanta()&&calendarSelected==='2026-07-10'?records.map(r=>'<div class="gm-calendar-event"><time>'+r.time+'</time><strong>'+r.title+'</strong><p>'+r.people.join(', ')+'</p></div>').reverse().join(''):'<div class="gm-calendar-empty">'+icon('calendar-days')+'<p>Нет известных событий на эту дату.</p></div>')+'<p class="gm-journalhint">Просмотр календаря не меняет игровое время.</p></section></div>','wide','calendar');
      body.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;if(b.dataset.gmCalendarDay){calendarSelected=b.dataset.gmCalendarDay;calendar();}if(b.dataset.gmCalendarMonth){calendarMonth=b.dataset.gmCalendarMonth;calendarSelected=calendarMonth+'-01';calendarYear=false;calendar();}if(b.dataset.gmCalendarMode){calendarYear=b.dataset.gmCalendarMode==='year';calendar();}if(b.hasAttribute('data-gm-calendar-today')){calendarMonth=today.slice(0,7);calendarSelected=today;calendar();}if(b.hasAttribute('data-gm-month-step')){const next=new Date(Date.UTC(y,m+Number(b.dataset.gmMonthStep)*(calendarYear?12:1),1));calendarMonth=iso(next).slice(0,7);calendarSelected=calendarMonth+'-01';calendar();}});
    }

    ui.register('game',()=>{syncPeople();game();});
    ui.register('camera',()=>{syncPeople();camera();});
    ui.register('time-skip',timeSkip);
    ui.register('long-term',longTerm);
    ui.register('policy',policy);
    ui.register('protagonist',()=>{syncPeople();protagonist();});
    ui.register('calendar',()=>{syncPeople();calendar();});
  };
})();

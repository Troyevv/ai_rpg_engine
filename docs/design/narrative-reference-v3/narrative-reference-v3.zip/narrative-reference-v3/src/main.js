(function(){
  'use strict';
  const root=document.getElementById('nr-app');
  if(!root)return;
  const q=s=>root.querySelector(s), qa=s=>Array.from(root.querySelectorAll(s));
  const ui=root.__nrUI;
  const feed=q('.nr-feed'), input=q('#nr-action'), send=q('.nr-send'), stop=q('[data-stop]'), turns=q('[data-turns]');
  const initialHTML=turns.innerHTML;
  let running=false, frame=0, currentStream=null, follow=true, turnNumber=0, variant=1, toastTimer=0, lastPanelOpener=null, lastSheetOpener=null;
  let history=[], phone=null;
  let selectedChoiceIndex=null, sendingChoiceIndex=null, choicePanelLevel=2;
  const campaignSnapshots=new Map();
  const initialState={...ui.state};
  let lastActorKey='';
  const reduced=()=>root.classList.contains('nr-reduced')||root.dataset.sfMotion==='false'||window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const choices=[
    {action:'Подсказать дочери выгодное для себя решение',speech:'Мёрф, ты только не спеши. Приговор можно отложить, если обвиняемый сам помоет посуду.'},
    {action:'Перевести разговор на школьное воспоминание',speech:'Тим, а помнишь, как мы в школе на спор съели по три пирожка из столовой за минуту?'},
    {action:'Заглянуть в блокнот Сони',speech:'Соня, а ты что записываешь? Я хочу потом это прочитать.'},
    {action:'Подложить Тимуру ещё кусок мяса, молча и с преувеличенной заботой'},
    {action:'Предложить Мёрфи вынести приговор',speech:'Ладно, судья, а какой у тебя приговор для папы?'},
    {action:'Поддразнить Катю насчёт её тишины',speech:'Катя, ты чего притихла? Обычно ты первая предлагаешь что-нибудь безумное.'}
  ];
  const laterChoices=[
    {action:'Посмотреть на Соню',speech:'Ну что, адвокат у меня сегодня будет?'},
    {action:'Наклониться к Мёрфи',speech:'А пересмотр приговора после десерта возможен?'},
    {action:'Подвинуть Кате тарелку',speech:'Сначала ужин. А потом можешь предлагать любые наказания.'},
    {action:'Поднять стакан и с серьёзным видом кивнуть всей комиссии'},
    {action:'Попросить Тимура помочь',speech:'Друг, ты ведь не оставишь меня один на один с посудой?'},
    {action:'Сменить тему',speech:'Так какие у нас планы на выходные?'}
  ];
  let currentChoices=choices;
  let responseVariants=[{html:turns.querySelector('.nr-prose').innerHTML,choices,complete:true}];
  const choiceText=c=>!c.action?c.speech:!c.speech?c.action:c.action+(c.action.endsWith(':')?' ':': ')+'«'+c.speech+'»';
  const icons=()=>{if(window.lucide)window.lucide.createIcons({attrs:{width:16,height:16}});qa('button').forEach(b=>b.classList.add('cursor-interaction'));};
  const announce=text=>{q('[data-live-status]').textContent=text;};
  const toast=text=>{clearTimeout(toastTimer);q('[data-toast]').textContent=text;q('[data-toast]').classList.add('nr-show');toastTimer=setTimeout(()=>q('[data-toast]').classList.remove('nr-show'),2900);};
  const esc=value=>String(value==null?'':value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fullName=name=>(ui.state.people||[]).find(p=>p.name===name)?.full||ui.names[name]||name||'Наблюдатель';
  const initials=name=>fullName(name).split(' ').map(s=>s[0]).slice(0,2).join('');
  const clock=()=>String(Math.floor(ui.state.minutes/60)).padStart(2,'0')+':'+String(ui.state.minutes%60).padStart(2,'0');
  const keyOf=state=>state.worldId+'::'+state.saveId;
  function peopleFor(values){return (values||Object.values(ui.names)).map((value,i)=>typeof value==='object'?value:{name:value.split(' ')[0],full:value,initials:value.split(' ').map(s=>s[0]).slice(0,2).join(''),tone:['gold','rose','blue','green','lilac'][i%5]});}
  function sceneChoices(){
    if(ui.state.observer)return [{action:'Посмотреть, что происходит в этой сцене'},{action:'Сосредоточиться на разговоре персонажей'},{action:'Наблюдать за изменениями вокруг'}];
    if(ui.state.worldId==='santa'&&ui.state.actor==='Илья')return turnNumber?laterChoices:choices;
    if(ui.state.worldId==='birch')return [{action:'Посмотреть на расписание у выхода'},{action:'Обратиться к Нине',speech:'Вы не знаете, когда будет следующий поезд?'},{action:'Заговорить с Виктором',speech:'Вы тоже опоздали на автобус?'},{action:'Заказать ещё один чай'},{action:'Проверить время на телефоне'},{action:'Посмотреть в окно на привокзальную площадь'}];
    if(ui.state.worldId==='orbit')return [{action:'Подойти к иллюминатору'},{action:'Спросить о ночной смене',speech:'Есть что-нибудь необычное в плане на ночь?'},{action:'Посмотреть текущие показания станции'},{action:'Поднять взгляд от планшета',speech:'Кто-нибудь уже проверил связь с Землёй?'},{action:'Налить воды и присесть у общего стола'},{action:'Проверить список задач на терминале'}];
    return [{action:'Оглядеться и прислушаться к разговору'},{action:'Уточнить детали',speech:'А что было дальше?'},{action:'Обратиться к собеседникам',speech:'Подождите, у меня есть вопрос.'},{action:'Дать остальным закончить мысль'},{action:'Перевести внимание на происходящее рядом'},{action:'Предложить обсудить планы',speech:'Что будем делать дальше?'}];
  }
  function refreshUI(){
    const s=ui.state,people=s.people||peopleFor();
    const selector=q('#nr-actor');selector.replaceChildren();
    if(s.observer){const option=document.createElement('option');option.value='';option.textContent='Камера наблюдателя';selector.append(option);}
    people.forEach(p=>{const option=document.createElement('option');option.value=p.name;option.textContent=p.full+(s.protagonist===p.name?' · основной герой':'');option.selected=!s.observer&&s.actor===p.name;selector.append(option);});
    selector.value=s.observer?'':s.actor;selector.disabled=running||!people.length;
    q('[data-actor-initials]').textContent=s.observer?'К':initials(s.actor);
    q('[data-writing-actor]').textContent=s.observer?'Направление для мира':fullName(s.actor);
    syncPlaceholder();
    q('[data-observer-bar]').hidden=!s.observer;q('[data-return-bar]').hidden=s.observer||s.actor===s.protagonist;
    q('[data-observer-label]').textContent='Наблюдение'+(s.observedActor?' · '+fullName(s.observedActor):' · Мир без главного героя');
    q('[data-control-caption]').textContent='Сейчас под управлением: '+fullName(s.actor);
    qa('[data-return-hero]').forEach(b=>{b.textContent='Вернуться к '+fullName(s.protagonist);b.disabled=!s.protagonist||running;});
    q('[data-world-time]').textContent=clock();
    q('.ph-clock').textContent=clock();q('.ph-owner').innerHTML='<i data-lucide="smartphone" aria-hidden="true"></i>'+esc(fullName(s.actor||s.protagonist));q('.ph-device').setAttribute('aria-label','Игровой телефон: '+fullName(s.actor||s.protagonist));
    const date=new Date(Date.UTC(2026,6,10+s.dayOffset));const label=date.toLocaleDateString('ru-RU',{weekday:'long',day:'numeric',month:'long',year:'numeric',timeZone:'UTC'});q('[data-world-date]').textContent=label[0].toUpperCase()+label.slice(1);
    const peopleRow=q('.nr-people');peopleRow.replaceChildren();people.filter(p=>p.name!==s.actor).forEach(p=>{const b=document.createElement('button');b.className='nr-person';b.dataset.profile=p.name;b.innerHTML='<span class="nr-miniav">'+esc(p.name[0])+'</span>'+esc(p.name);peopleRow.append(b);});
    const actorKey=s.worldId+'::'+s.actor+'::'+s.observer;if(lastActorKey&&lastActorKey!==actorKey&&!running){renderChoices(sceneChoices());draftState();}lastActorKey=actorKey;
    q('[data-background]').disabled=running;q('[data-observe-more]').disabled=running;
    icons();
  }
  function addMinutes(delta){const total=ui.state.dayOffset*1440+ui.state.minutes+delta;ui.update({dayOffset:Math.floor(total/1440),minutes:((total%1440)+1440)%1440});}
  function snapshot(){return {html:turns.innerHTML,text:input.value,turnNumber,choices:currentChoices,variant,variants:responseVariants.map(saved=>({...saved})),state:{...ui.state},choicePanelLevel,scroll:feed.scrollTop,phone:phone?.snapshot?.()};}
  function remember(){history.push(snapshot());}
  function quietOlderTurns(){turns.querySelectorAll('.nr-turntop').forEach(el=>{el.querySelector('span:nth-child(2)').textContent='Ранее';});turns.querySelectorAll('.nr-responseactions').forEach(el=>el.hidden=true);}
  function renderChoices(items){
    currentChoices=items;selectedChoiceIndex=null;
    q('[data-choices-grid]').replaceChildren();
    q('[data-extra-choices]')?.replaceChildren();
    if(q('.nr-morechoices')){q('.nr-morechoices').hidden=true;q('.nr-morechoices').inert=true;}
    if(q('[data-toggle-more]'))q('[data-toggle-more]').hidden=true;
    items.forEach((c,i)=>{
      const b=document.createElement('button');b.type='button';b.className='nr-choice';b.dataset.choice=String(i);b.setAttribute('aria-pressed','false');b.disabled=running;
      const mark=document.createElement('span');mark.className='nr-choice-mark';mark.setAttribute('aria-hidden','true');
      const copy=document.createElement('span');copy.className='nr-choicecopy';
      if(c.action){const strong=document.createElement('strong');strong.className='nr-choice-action';strong.textContent=c.action;copy.append(strong);}
      if(c.speech){const speech=document.createElement('span');speech.className='nr-choice-speech';speech.textContent='«'+c.speech+'»';copy.append(speech);}
      b.append(mark,copy);q('[data-choices-grid]').append(b);
    });
    const count=q('.nr-choices .nr-count');if(count)count.textContent=String(items.length);
    syncChoiceStates();syncChoicePanel();
  }
  function syncChoiceStates(){
    let iconsChanged=false;
    qa('[data-choice]').forEach(b=>{
      const index=Number(b.dataset.choice), chosen=index===selectedChoiceIndex, sending=running&&index===sendingChoiceIndex;
      const icon=sending?'loader-circle':chosen?'check':currentChoices[index]?.speech?'message-circle':'arrow-up-right';
      b.setAttribute('aria-pressed',String(chosen));b.disabled=running;
      if(sending)b.setAttribute('aria-busy','true');else b.removeAttribute('aria-busy');
      const mark=b.querySelector('.nr-choice-mark');
      if(mark&&mark.dataset.icon!==icon){mark.dataset.icon=icon;mark.innerHTML='<i data-lucide="'+icon+'"></i>';iconsChanged=true;}
    });
    if(iconsChanged)icons();
  }
  function syncChoicePanel(){
    const panel=q('.nr-choices'), body=q('#nr-choices-body'), toggle=q('[data-toggle-choices]');
    panel.dataset.level=String(choicePanelLevel);panel.hidden=running;
    body.classList.toggle('nr-expanded',choicePanelLevel!==0);body.inert=running||choicePanelLevel===0;
    toggle.setAttribute('aria-expanded',String(choicePanelLevel!==0));
    toggle.setAttribute('aria-label',choicePanelLevel===2?'Свернуть список вариантов действий':choicePanelLevel===0?'Раскрыть компактный список вариантов действий':'Показать весь список вариантов действий');
    const hint=q('[data-choice-level]');if(hint)hint.textContent=['Свёрнуто','Компактно','Полностью'][choicePanelLevel];
  }
  function cycleChoicePanel(){
    choicePanelLevel=choicePanelLevel===2?0:choicePanelLevel+1;syncChoicePanel();
  }
  function draftState(){
    const length=input.value.trim().length;
    send.disabled=!length||running;q('[data-clear-draft]').hidden=!length;
    q('[data-draft-status]').textContent=running?'Появляется ответ…':length?'Можно изменить перед отправкой':'Твой ход';
    q('[data-counter]').textContent=length?length+' / 4000':'Действие определяешь ты';
    input.style.height='auto';input.style.height=Math.min(104,Math.max(42,input.scrollHeight))+'px';input.style.overflowY=input.scrollHeight>104?'auto':'hidden';
    syncChoiceStates();
  }
  function syncVariantControls(){
    const article=turns.querySelector('.nr-turn:last-child');if(!article)return;
    const label=article.querySelector('[data-variant-label]');if(!label)return;
    let previous=article.querySelector('[data-variant-prev]'), next=article.querySelector('[data-variant-next]');
    if(!previous){
      previous=document.createElement('button');previous.type='button';previous.className='nr-variantstep';previous.setAttribute('data-variant-prev','');previous.setAttribute('aria-label','Предыдущий вариант ответа');previous.innerHTML='<i data-lucide="chevron-left" aria-hidden="true"></i>';label.before(previous);
      next=document.createElement('button');next.type='button';next.className='nr-variantstep';next.setAttribute('data-variant-next','');next.setAttribute('aria-label','Следующий вариант ответа');next.innerHTML='<i data-lucide="chevron-right" aria-hidden="true"></i>';label.after(next);icons();
    }
    label.textContent=variant+' из '+responseVariants.length;
    previous.disabled=running||variant<=1;next.disabled=running||variant>=responseVariants.length;
  }
  function saveVariant(article,complete,items){
    responseVariants[variant-1]={html:article.querySelector('.nr-prose').innerHTML,choices:items,complete};
    renderChoices(items);draftState();syncVariantControls();
  }
  function switchVariant(delta,opener){
    const target=variant+delta;if(running||target<1||target>responseVariants.length)return;
    const article=turns.querySelector('.nr-turn:last-child');if(!article)return;
    variant=target;const saved=responseVariants[variant-1];article.querySelector('.nr-prose').innerHTML=saved.html;
    renderChoices(saved.choices);draftState();syncVariantControls();icons();
    if(opener?.disabled)article.querySelector(delta<0?'[data-variant-next]':'[data-variant-prev]')?.focus({preventScroll:true});
    announce('Выбран вариант '+variant+' из '+responseVariants.length+(saved.complete?'.':'. Ответ был остановлен.'));
  }
  function setBusy(value){
    if(value&&!running)sendingChoiceIndex=selectedChoiceIndex;
    if(!value)sendingChoiceIndex=null;
    running=value;send.hidden=value;stop.hidden=!value;input.readOnly=value;
    qa('[data-choice],[data-regenerate]').forEach(b=>b.disabled=value);
    q('[data-undo]').disabled=value||history.length===0;
    q('[data-request-undo]').disabled=value||history.length===0;
    qa('#nr-actor,[data-background],[data-observe-more],[data-return-hero],[data-ui="game"],[data-ui="worlds"],[data-ui="camera"],[data-ui="calendar"]').forEach(b=>b.disabled=value);
    q('[data-save-label]').textContent=value?'Создаётся ответ':'Сохранено';
    q('.nr-choices').setAttribute('aria-busy',String(value));syncChoicePanel();draftState();syncVariantControls();
  }
  function bottom(smooth){follow=true;feed.scrollTo({top:feed.scrollHeight,behavior:smooth&&!reduced()?'smooth':'auto'});q('[data-jump]').hidden=true;}
  feed.addEventListener('scroll',()=>{follow=feed.scrollHeight-feed.clientHeight-feed.scrollTop<65;q('[data-jump]').hidden=follow;},{passive:true});
  function selectChoice(index){
    if(running||!currentChoices[index])return;
    const proposal=choiceText(currentChoices[index]);
    const writeChoice=text=>{
      selectedChoiceIndex=index;input.value=text;draftState();input.focus({preventScroll:true});
      announce('Вариант перенесён в поле ввода. Его можно изменить.');
    };
    if(!input.value.trim()||input.value===proposal){writeChoice(proposal);return;}
    const ui=root.__nrUI;
    if(!ui?.modal){toast('В поле уже есть черновик. Очисти его, чтобы выбрать другое действие.');return;}
    const source=currentChoices;
    const body=ui.modal({title:'В поле уже есть черновик',subtitle:'Добавить предложение к твоему тексту или заменить его?',size:'normal',html:'<p class="nr-choice-draft-label">Предложение</p><blockquote class="nr-choice-draft-preview" data-choice-preview></blockquote><p class="nr-choice-draft-error" data-choice-draft-error role="status" hidden></p><div class="nr-choice-draft-actions"><button type="button" class="nr-choice-draft-action nr-choice-draft-primary" data-choice-draft="add"><i data-lucide="plus" aria-hidden="true"></i>Добавить к черновику</button><button type="button" class="nr-choice-draft-action" data-choice-draft="replace">Заменить черновик</button><button type="button" class="nr-choice-draft-action nr-choice-draft-cancel" data-choice-draft="cancel">Отмена</button></div>'});
    body.querySelector('[data-choice-preview]').textContent=proposal;ui.icons();
    body.addEventListener('click',event=>{
      const button=event.target.closest('[data-choice-draft]');if(!button)return;
      const action=button.dataset.choiceDraft;
      if(action==='cancel'){ui.close();input.focus({preventScroll:true});return;}
      if(running||currentChoices!==source){ui.close();return;}
      const text=action==='add'?input.value+'\n'+proposal:proposal;
      if(input.maxLength>0&&text.length>input.maxLength){
        const error=body.querySelector('[data-choice-draft-error]');error.textContent='Не помещается в '+input.maxLength+' символов. Твой черновик сохранён — сократи его перед добавлением.';error.hidden=false;return;
      }
      ui.close();writeChoice(text);
    });
  }
  function makeUserTurn(text){
    const d=document.createElement('div');d.className='nr-userturn';
    const a=document.createElement('span');a.className='nr-avatar nr-avatarplayer';a.textContent=ui.state.observer?'К':initials(ui.state.actor);
    const p=document.createElement('p');p.textContent=text;d.append(a,p);return d;
  }
  function responseFor(text){
    if(ui.state.observer)return 'Внимание камеры остаётся на текущей сцене. Разговор продолжается без действия со стороны главного героя.\n\n'+worldResponse();
    if(ui.state.worldId!=='santa'||ui.state.actor!=='Илья')return worldResponse();
    if(/блокнот|записываешь|прочитать/i.test(text))return 'Соня прикрывает страницу ладонью, но блокнот не отодвигает.\n\n— Протокол, — отвечает она с невозмутимым видом. — Особенно удачные формулировки пойдут в семейный архив.\n\nМёрфи тянется через стол:\n\n— И мой приговор запиши! Папа моет посуду, а потом мы все идём за мороженым.\n\n— Вот это уже толковая программа, — говорит Тимур. Катя наконец смеётся и придвигает к тебе блюдо обратно.\n\nСоня поворачивает блокнот. Под заголовком «Судебное заседание» вместо протокола нарисован человечек с огромной губкой в руке.';
    if(/Кат[яеюи]|молчание|притихла/i.test(text))return 'Катя медленно поднимает глаза и кладёт вилку поперёк тарелки.\n\n— Я просто ждала, когда вы закончите с формальностями. У меня уже три варианта наказания.\n\n— Не слушай её, — быстро говорит Тимур. — Последний раз после этой фразы мы красили забор до полуночи.\n\nМёрфи поворачивается к Кате всем корпусом.\n\n— А какие три?\n\nСоня тихо придвигает блокнот ближе. Кажется, у этого заседания появились дополнительные материалы.';
    if(/мяса|заботой|Тимуру/i.test(text))return 'Тимур смотрит сначала на свою тарелку, потом на тебя.\n\n— Это взятка свидетелю? — спрашивает он и тут же прикрывает мясо вилкой. — Я не утверждаю. Просто уточняю.\n\n— Записала, — снова говорит Соня.\n\nМёрфи хлопает ладонью по столу, едва не опрокинув стакан. Катя ловит его за край и ставит подальше.\n\n— Тишина в суде! Свидетелю можно добавку. А папе — посуду.';
    if(/посуд|приговор|судья|Мёрф/i.test(text))return 'Мёрфи прищуривается, явно взвешивая предложение. Потом вытягивает палец.\n\n— Посуду всю. Даже сковородку. И мороженое после ужина.\n\n— Какой талант к переговорам, — бормочет Тимур. — В кого же она такая?\n\nСоня, не глядя, пихает его локтем. Катя уже достаёт из стопки чистую тарелку и торжественно ставит перед тобой.\n\n— Для начала можешь поесть, подсудимый. Мы сегодня добрые.\n\nИз приоткрытого окна тянет прохладой; на улице кто-то заводит мотоцикл. Мёрфи ждёт ответа, обхватив стакан обеими руками.';
    return 'Тимур отставляет стакан и наклоняется ближе к столу.\n\n— Так, стоп. Это надо обсудить нормально, — говорит он, не сдержав улыбки.\n\nСоня откладывает ручку. Мёрфи переводит взгляд с неё на тебя, а Катя подвигает к себе стул, чтобы слышать лучше.\n\n— Давай, — говорит Соня. — Мы слушаем.\n\nУжин на минуту замедляется. Из кухни доносится тихое гудение холодильника, а на столе между тарелками лежит раскрытый блокнот.';
  }
  function startStream(article,text,onDone){
    const p=article.querySelector('.nr-streamcopy');const node=document.createTextNode('');p.replaceChildren(node);p.classList.add('nr-streaming');
    let started=0,last=0,position=0;
    currentStream={p,text,onDone,finish:()=>{
      cancelAnimationFrame(frame);p.classList.remove('nr-streaming');
      if(position<text.length){const note=document.createElement('span');note.textContent='\n\nОтвет остановлен.';note.style.color='#a3aab5';note.style.fontSize='12px';p.append(note);}
      currentStream=null;onDone(false);setBusy(false);announce('Ответ остановлен. Можно продолжить игру.');
    }};
    function tick(now){
      if(!started)started=now;
      if(now-last>=38){
        last=now;position=Math.min(text.length,Math.floor((now-started)*.18)+1);node.textContent=text.slice(0,position);
        if(follow)feed.scrollTop=feed.scrollHeight;
      }
      if(position<text.length)frame=requestAnimationFrame(tick);
      else{p.classList.remove('nr-streaming');currentStream=null;onDone(true);setBusy(false);announce('Ответ готов. Доступны новые варианты действий.');if(follow){const panel=q('.nr-choices');feed.scrollTop=Math.max(0,panel.offsetTop-feed.clientHeight*.66);}}
    }
    frame=requestAnimationFrame(tick);
  }
  function newArticle(time){
    const a=document.createElement('article');a.className='nr-turn';a.dataset.turn=String(turnNumber);a.setAttribute('aria-label','Новый ответ');
    a.innerHTML='<div class="nr-turntop"><span class="nr-nowmark"></span><span>Сейчас</span><span class="nr-metadot">·</span><span class="nr-turntime">'+time+'</span></div><div class="nr-prose"><p class="nr-streamcopy"></p></div><div class="nr-responseactions"><span class="nr-variantlabel">Вариант <span data-variant-label>1 из 1</span></span><button class="nr-textbutton" data-regenerate><i data-lucide="plus" aria-hidden="true"></i>Ещё вариант</button><button class="nr-textbutton nr-turnmore" data-open-details><i data-lucide="chart-no-axes-combined" aria-hidden="true"></i>Контекст / usage</button></div>';
    return a;
  }
  function submit(){
    const text=input.value.trim();if(!text||running)return;
    remember();turnNumber++;variant=1;quietOlderTurns();
    turns.append(makeUserTurn(text));addMinutes(1);const a=newArticle(clock());turns.append(a);
    const nextChoices=sceneChoices();responseVariants=[{html:a.querySelector('.nr-prose').innerHTML,choices:nextChoices,complete:false}];
    input.value='';setBusy(true);icons();bottom(true);
    startStream(a,responseFor(text),complete=>saveVariant(a,complete,nextChoices));
  }
  function undo(){
    if(running||!history.length)return;
    const h=history.pop();turns.innerHTML=h.html;turnNumber=h.turnNumber;variant=h.variant;responseVariants=h.variants.map(saved=>({...saved}));input.value=h.text;ui.update(h.state);renderChoices(h.choices);setBusy(false);icons();closePanels();bottom(false);toast('Ход отменён. Черновик и время восстановлены.');input.focus({preventScroll:true});
  }
  function requestUndo(){if(running||!history.length)return;const body=ui.modal({title:'Откатить последний ход?',subtitle:'В демонстрации восстановятся предыдущий ответ, время и черновик действия.',html:'<div class="ui-row"><button class="ui-button" data-cancel-undo>Отмена</button><button class="ui-button primary" data-confirm-undo>Откатить ход</button></div>'});body.querySelector('[data-cancel-undo]').addEventListener('click',()=>ui.close());body.querySelector('[data-confirm-undo]').addEventListener('click',()=>{ui.close();undo();});}
  function worldResponse(){
    if(ui.state.worldId==='birch')return 'Нина задерживается у окна и смотрит на опустевшую площадь.\n\n— До следующего поезда ещё есть время, — говорит она. — Я могу пока не выключать чайник.\n\nВиктор складывает расписание пополам. Снаружи снова начинается мелкий дождь; под навесом останавливается человек с дорожной сумкой.';
    if(ui.state.worldId==='orbit')return 'Мира проводит пальцем по строке на терминале.\n\n— По станции всё спокойно. Следующее окно связи через десять минут.\n\nЛеон снимает наушник и поворачивается к общему столу. За иллюминатором медленно уходит в тень край Земли. В отсеке слышен ровный шум вентиляции.';
    if(ui.state.worldId==='santa')return 'Тимур отставляет стакан.\n\n— А если создать независимую комиссию по посуде?\n\n— Комиссия уже создана, — отвечает Соня и подвигает блокнот к Мёрфи. Катя прячет улыбку за чашкой.\n\nМёрфи внимательно смотрит на взрослых.\n\n— Тогда сначала закончим ужин. А потом я решу.';
    return 'Сцена остаётся открытой для твоего следующего действия. В этом концепте показан демонстрационный ответ; генерация событий для созданного мира требует подключения движка.';
  }
  function systemTurn(delta,kind){
    if(running)return;remember();turnNumber++;variant=1;quietOlderTurns();addMinutes(delta);
    const badge=document.createElement('div');badge.className='nr-systemturn';badge.textContent=kind==='background'?'Мир без главного героя':kind==='observe'?'Продолжение наблюдения':kind==='long-term'?'Долгосрочное развитие мира':'Пропуск времени';turns.append(badge);
    const a=newArticle(clock());turns.append(a);const nextChoices=sceneChoices();responseVariants=[{html:'',choices:nextChoices,complete:false}];setBusy(true);icons();bottom(true);
    const text=kind==='long-term'?'Время мира переместилось вперёд. В полном движке здесь появится результат развития персонажей и событий за выбранный период.\n\nВ концепте можно проверить новый календарь, сохранение состояния прохождения и откат этого перехода.':(kind==='time-skip'&&delta>60?'Прошёл выбранный интервал времени. Новое время уже отражено в календаре.\n\n':'')+worldResponse();
    startStream(a,text,complete=>saveVariant(a,complete,nextChoices));
  }
  function switchCampaign(value){
    if(running){toast('Дождись ответа или останови его перед сменой прохождения.');return;}
    campaignSnapshots.set(keyOf(ui.state),{...snapshot(),history:history.slice()});
    const saved=campaignSnapshots.get(keyOf(value));phone?.destroy();phone=null;closeSheet(false);closePanels();
    if(saved){history=saved.history.slice();turns.innerHTML=saved.html;turnNumber=saved.turnNumber;variant=saved.variant;responseVariants=saved.variants.map(v=>({...v}));choicePanelLevel=saved.choicePanelLevel;ui.update(saved.state);input.value=saved.text;renderChoices(saved.choices);feed.scrollTop=saved.scroll;}
    else{
      const people=peopleFor(value.people||[]);const hero=people[0]?.name||null;
      history=[];turnNumber=0;variant=1;choicePanelLevel=2;input.value='';ui.update({...initialState,...value,people,actor:hero,protagonist:hero,observer:!hero,observedActor:null,minutes:1208,dayOffset:0});
      if(value.worldId==='santa')turns.innerHTML=initialHTML;
      else{turns.replaceChildren();const a=newArticle(clock());a.querySelector('.nr-prose').innerHTML='<p>'+esc(worldResponse()).replace(/\n\n/g,'</p><p>')+'</p>';turns.append(a);}
      const nextChoices=sceneChoices();responseVariants=[{html:turns.querySelector('.nr-turn:last-child .nr-prose').innerHTML,choices:nextChoices,complete:true}];renderChoices(nextChoices);feed.scrollTop=0;
    }
    phone=window.installNarrativePhone?window.installNarrativePhone(root,saved?.phone):null;
    setBusy(false);refreshUI();icons();announce('Открыто прохождение '+ui.state.saveName+'. Черновик восстановлен.');
  }
  function regenerate(){
    if(running)return;
    const last=turns.querySelector('.nr-turn:last-child');if(!last)return;
    const nextChoices=currentChoices;
    responseVariants[variant-1]={...responseVariants[variant-1],html:last.querySelector('.nr-prose').innerHTML,choices:currentChoices};
    responseVariants.push({html:'<p class="nr-streamcopy"></p>',choices:nextChoices,complete:false});variant=responseVariants.length;
    const text=ui.state.worldId==='santa'&&ui.state.actor==='Илья'&&variant%2===0?'— Суд удаляется на совещание, — объявляет Мёрфи и тут же наклоняется к Кате.\n\nТа слушает очень серьёзно, только уголок рта выдаёт её с головой.\n\n— Поддерживаю. С поправкой на мороженое, — говорит Катя.\n\nТимур тихонько двигает к тебе последнюю чистую вилку.\n\n— Держись. Я морально с тобой.\n\nСоня перечёркивает строчку в блокноте и вписывает новую.\n\n— Решение окончательное, — зачитывает она. — Но подсудимый ещё может выступить с последним словом.':responseFor('приговор');
    last.querySelector('.nr-prose').innerHTML='<p class="nr-streamcopy"></p>';setBusy(true);bottom(false);startStream(last,text,complete=>saveVariant(last,complete,nextChoices));
  }
  function closePanels(restore){
    const wasOpen=!q('[data-display-panel]').hidden||!q('[data-game-panel]').hidden;
    const opener=lastPanelOpener;lastPanelOpener=null;
    q('[data-display-panel]').hidden=true;q('[data-game-panel]').hidden=true;qa('[data-open-display],[data-open-menu]').forEach(b=>b.setAttribute('aria-expanded','false'));if(restore&&wasOpen&&opener?.isConnected)opener.focus({preventScroll:true});
  }
  function togglePanel(type,opener){const panel=q(type==='display'?'[data-display-panel]':'[data-game-panel]');const open=panel.hidden;closePanels();if(open){lastPanelOpener=opener;panel.hidden=false;opener.setAttribute('aria-expanded','true');panel.querySelector('button').focus({preventScroll:true});}}
  function openSheet(caption,html,opener){closePanels();if(phone)phone.close();lastSheetOpener=opener||document.activeElement;q('[data-sheet-caption]').textContent=caption;q('[data-sheet-body]').innerHTML=html;q('[data-sheet]').inert=false;q('[data-sheet]').classList.add('nr-open');q('[data-sheet-backdrop]').hidden=false;icons();q('[data-close-sheet]').focus({preventScroll:true});}
  function closeSheet(restore){q('[data-sheet]').classList.remove('nr-open');q('[data-sheet]').inert=true;q('[data-sheet-backdrop]').hidden=true;if(restore&&lastSheetOpener&&lastSheetOpener.isConnected)lastSheetOpener.focus({preventScroll:true});}
  function syncPlaceholder(){const compact=(root.clientWidth||1024)<=680;input.placeholder=ui.state.observer?(compact?'Направление камеры…':'Куда направить внимание камеры?'):(compact?'Твоё действие…':'Что ты делаешь или говоришь?');q('#nr-actor').querySelectorAll('option').forEach(option=>{const p=(ui.state.people||[]).find(person=>person.name===option.value);if(!p)return;const label=p.full+(!compact&&p.name===ui.state.protagonist?' · основной герой':'');if(option.textContent!==label)option.textContent=label;});}
  function navState(open,restore=false){root.classList.toggle('nr-navopen',open);q('[data-toggle-nav]').setAttribute('aria-expanded',String(open));q('.nr-navbackdrop').hidden=!open;q('.nr-stage').inert=open;if(open)q('.nr-sidebar button')?.focus({preventScroll:true});else if(restore)q('[data-toggle-nav]').focus({preventScroll:true});}
  const profiles={
    'Соня':{name:'Соня Величкина',initial:'СВ',tag:'Рядом · За общим столом',copy:'Сидит рядом с Тимуром. Ведёт шуточный протокол в блокноте и внимательно следит за семейным разбирательством.',now:'Превратила разговор о посуде в судебное заседание.'},
    'Тимур':{name:'Тимур Савельев',initial:'ТС',tag:'Рядом · За общим столом',copy:'Старый друг Ильи. Только что поставил на стол блюдо и теперь наблюдает за заседанием, пряча улыбку за стаканом.',now:'Подыгрывает Мёрфи, но готов выслушать сторону защиты.'},
    'Катя':{name:'Катя Соколова',initial:'КС',tag:'Рядом · За общим столом',copy:'Пока больше слушает. Отодвинула блюдо от Ильи, будто приговор уже вынесен.',now:'Следит за разговором и явно готовит свою реплику.'},
    'Мёрфи':{name:'Мёрфи Волкова',initial:'МВ',tag:'Рядом · За общим столом',copy:'Дочь Ильи. Только что получила право вынести окончательный приговор и относится к новой должности очень серьёзно.',now:'Спрашивает, можно ли самой придумать наказание.'},
    'Илья':{name:'Илья Волков',initial:'ИВ',tag:'Твой персонаж',copy:'Дома, за ужином с семьёй и друзьями. Попытка сослаться на тяжёлый рабочий день неожиданно привела к семейному судебному заседанию.',now:'Ты сам выбираешь его действия и реплики.'}
  };
  function showProfile(name,opener){const p=ui.state.worldId==='santa'?profiles[name]:null;if(!p){openSheet('Персонаж','<div class="nr-profilebig">'+esc(initials(name))+'</div><h2>'+esc(fullName(name))+'</h2><p>'+esc(ui.state.location)+'</p><h3>Демонстрационный персонаж</h3><p>Карточка показывает переход из сцены. Полные знания, отношения и биография загружаются из игрового мира в работающем приложении.</p>',opener);return;}openSheet('Персонаж','<div class="nr-profilebig">'+p.initial+'</div><h2>'+p.name+'</h2><div class="nr-profileline"><i data-lucide="map-pin" aria-hidden="true"></i>'+p.tag+'</div><p>'+p.copy+'</p><h3>В текущей сцене</h3><p>'+p.now+'</p>'+(name==='Соня'||name==='Тимур'||name==='Катя'?'<button class="nr-profileaction" data-open-phone><i data-lucide="smartphone" aria-hidden="true"></i>Открыть игровой телефон</button>':''),opener);}
  function showEvents(opener){openSheet('События сцены','<h2>За ужином</h2><p>Пятница, 10 июля 2026</p><div class="nr-eventrow"><time>20:08</time>Мёрфи назначена судьёй семейного разбирательства.</div><div class="nr-eventrow"><time>20:07</time>Соня начала вести шуточный протокол.</div><div class="nr-eventrow"><time>20:06</time>Разговор зашёл о том, кто будет мыть посуду.</div><div class="nr-eventrow"><time>20:00</time>Семья и друзья собрались за ужином.</div>',opener);}
  function showDetails(){const body=ui.modal({title:'Контекст / usage',kind:'context',subtitle:'Последний ответ · вариант '+variant+' из '+responseVariants.length,size:'wide',html:'<div class="ui-tabs" role="tablist" aria-label="Диагностика ответа"><button role="tab" aria-selected="true" data-context-tab="context">Контекст</button><button role="tab" aria-selected="false" data-context-tab="usage">Usage</button></div><div data-context-page></div>'});const page=body.querySelector('[data-context-page]');const render=tab=>{body.querySelectorAll('[data-context-tab]').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.contextTab===tab)));page.innerHTML=tab==='usage'?'<h3>Запрос к модели не выполнялся</h3><p class="ui-subtle">Это интерактивный концепт. Здесь нет фактических токенов, стоимости или времени генерации. В приложении этот раздел показывает usage ответа.</p>':'<div class="nr-detailrow"><span>Мир</span><strong>'+esc(ui.state.worldName)+'</strong></div><div class="nr-detailrow"><span>Управляемый персонаж</span><strong>'+esc(fullName(ui.state.actor))+'</strong></div><div class="nr-detailrow"><span>Сцена</span><strong>'+esc(ui.state.location)+'</strong></div><div class="nr-detailrow"><span>Время</span><strong>'+clock()+'</strong></div><details open><summary>Последнее действие</summary><p class="nr-context-copy">'+esc(history[history.length-1]?.text||'Начальная демонстрационная сцена')+'</p></details><details><summary>Повествование перед ответом</summary><p class="nr-context-copy">'+esc(turns.querySelector('.nr-turn:last-child .nr-prose').textContent)+'</p></details>';};body.querySelectorAll('[data-context-tab]').forEach(b=>b.addEventListener('click',()=>render(b.dataset.contextTab)));render('context');}
  function reset(){
    ui.close();cancelAnimationFrame(frame);currentStream=null;turns.innerHTML=initialHTML;history=[];turnNumber=0;variant=1;input.value='';selectedChoiceIndex=null;sendingChoiceIndex=null;choicePanelLevel=2;campaignSnapshots.clear();ui.update({...initialState,people:peopleFor()});
    responseVariants=[{html:turns.querySelector('.nr-prose').innerHTML,choices,complete:true}];
    q('[data-world-time]').textContent='20:08';renderChoices(choices);setBusy(false);icons();closePanels();closeSheet(false);
    q('.nr-previous').classList.remove('nr-expanded');q('.nr-previous').inert=true;q('[data-previous]').setAttribute('aria-expanded','false');
    phone?.destroy();phone=window.installNarrativePhone?window.installNarrativePhone(root):null;
    feed.scrollTop=0;toast('Демонстрационная сцена начата заново.');input.focus({preventScroll:true});
  }
  root.addEventListener('click',event=>{
    const b=event.target.closest('button');if(!b)return;
    if(b.hasAttribute('data-choice'))selectChoice(Number(b.dataset.choice));
    if(b.hasAttribute('data-toggle-choices'))cycleChoicePanel();
    if(b.hasAttribute('data-clear-draft')){input.value='';selectedChoiceIndex=null;draftState();input.focus({preventScroll:true});}
    if(b.hasAttribute('data-stop')&&currentStream)currentStream.finish();
    if(b.hasAttribute('data-jump'))bottom(true);
    if(b.hasAttribute('data-previous')){const open=b.getAttribute('aria-expanded')!=='true';b.setAttribute('aria-expanded',String(open));q('.nr-previous').classList.toggle('nr-expanded',open);q('.nr-previous').inert=!open;}
    if(b.hasAttribute('data-open-display'))togglePanel('display',b);
    if(b.hasAttribute('data-open-menu'))togglePanel('game',b);
    if(b.hasAttribute('data-close-panels'))closePanels(true);
    if(b.hasAttribute('data-focus-mode')){const active=root.classList.toggle('nr-focus');b.setAttribute('aria-pressed',String(active));announce(active?'Режим фокуса включён':'Режим фокуса выключен');}
    if(b.hasAttribute('data-font-size')){root.dispatchEvent(new CustomEvent('nr:appearance-change',{detail:{font:{small:14,normal:16,large:18}[b.dataset.fontSize]}}));qa('[data-font-size]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));}
    if(b.hasAttribute('data-profile'))showProfile(b.dataset.profile,b);
    if(b.hasAttribute('data-open-events'))showEvents(b);
    if(b.hasAttribute('data-open-details'))showDetails(b);
    if(b.hasAttribute('data-close-sheet'))closeSheet(true);
    if(b.hasAttribute('data-open-phone')){closePanels();closeSheet(false);}
    if(b.hasAttribute('data-regenerate'))regenerate();
    if(b.hasAttribute('data-variant-prev'))switchVariant(-1,b);
    if(b.hasAttribute('data-variant-next'))switchVariant(1,b);
    if(b.hasAttribute('data-undo'))undo();
    if(b.hasAttribute('data-request-undo'))requestUndo();
    if(b.hasAttribute('data-background')&&!running){ui.update({actor:null,observer:true,observedActor:null});systemTurn(1,'background');}
    if(b.hasAttribute('data-observe-more'))systemTurn(1,'observe');
    if(b.hasAttribute('data-return-hero'))ui.control(ui.state.protagonist);
    if(b.hasAttribute('data-reset'))reset();
    if(b.hasAttribute('data-toggle-nav'))navState(!root.classList.contains('nr-navopen'));
    if(b.hasAttribute('data-close-nav'))navState(false,true);
  });
  q('[data-sheet-backdrop]').addEventListener('click',()=>closeSheet(true));
  q('[data-main-form]').addEventListener('submit',e=>{e.preventDefault();submit();});
  input.addEventListener('input',()=>{selectedChoiceIndex=null;draftState();});
  input.addEventListener('keydown',e=>{if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)&&!e.isComposing){e.preventDefault();submit();}});
  q('[data-motion]').addEventListener('change',e=>root.dispatchEvent(new CustomEvent('nr:appearance-change',{detail:{motion:e.target.checked}})));
  q('[data-show-times]').addEventListener('change',e=>root.classList.toggle('nr-hide-times',!e.target.checked));
  root.addEventListener('keydown',e=>{
    if(e.key==='Tab'&&root.classList.contains('nr-navopen')){const a=Array.from(q('.nr-sidebar').querySelectorAll('button:not(:disabled)'));const first=a[0],last=a[a.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}return;}
    if(e.key==='Escape'){
      if(root.classList.contains('nr-navopen')){navState(false,true);return;}
      if(q('.ph-device')?.classList.contains('ph-is-open'))return;
      if(q('[data-sheet]').classList.contains('nr-open')){closeSheet(true);return;}
      closePanels(true);
    }
    if(e.key==='Tab'&&q('[data-sheet]').classList.contains('nr-open')){const a=Array.from(q('[data-sheet]').querySelectorAll('button:not(:disabled),input,textarea'));const first=a[0],last=a[a.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}
  });
  document.addEventListener('pointerdown',e=>{if(!root.contains(e.target)||!e.target.closest('.nr-popover,[data-open-display],[data-open-menu]'))closePanels();});
  root.addEventListener('narrative:phone-unread',e=>{const unread=q('[data-phone-unread]');unread.textContent=String(e.detail.count);unread.hidden=e.detail.count===0;});
  q('#nr-actor').addEventListener('change',e=>{if(e.target.value)ui.control(e.target.value);});
  root.addEventListener('nr:modal-will-open',()=>{closePanels();closeSheet(false);phone?.close();navState(false);});
  root.addEventListener('nr:viewport-change',()=>{closePanels();navState(false);});
  if(typeof ResizeObserver!=='undefined'){
    const layoutObserver=new ResizeObserver(()=>{syncPlaceholder();draftState();if(root.clientWidth>680&&root.classList.contains('nr-navopen'))navState(false);});layoutObserver.observe(root);
    const composerObserver=new ResizeObserver(()=>{root.style.setProperty('--nr-composer-height',q('.nr-composerarea').getBoundingClientRect().height+'px');});composerObserver.observe(q('.nr-composerarea'));
  }
  ui.bind({refresh:refreshUI,notice:toast,profile:showProfile,advance:systemTurn,observe:name=>toast('Камера наблюдает: '+fullName(name)+'. Время не изменилось.'),switchCampaign,reset});
  ui.register('game-home',()=>{ui.close();closeSheet(false);navState(false);});
  ui.register('mobile-menu',()=>{const body=ui.modal({title:'Игровые действия',kind:'menu',html:'<div class="nr-mobile-actions"><button data-ui="camera"><i data-lucide="scan-eye" aria-hidden="true"></i>Камера · Журнал</button><button data-mobile-background><i data-lucide="orbit" aria-hidden="true"></i>Мир без главного героя</button><button data-ui="world"><i data-lucide="panel-right" aria-hidden="true"></i>О мире</button><button data-ui="events"><i data-lucide="bell" aria-hidden="true"></i>События истории</button><button data-mobile-focus><i data-lucide="eye" aria-hidden="true"></i>Режим фокуса</button><button data-ui="settings" data-section="appearance"><i data-lucide="type" aria-hidden="true"></i>Текст и оформление</button><button data-ui="settings"><i data-lucide="sliders-horizontal" aria-hidden="true"></i>Настройки</button></div>'});body.querySelector('[data-mobile-background]').disabled=running;body.querySelector('[data-mobile-background]').addEventListener('click',()=>{ui.close();q('[data-background]').click();});body.querySelector('[data-mobile-focus]').addEventListener('click',()=>{ui.close();q('[data-focus-mode]').click();});ui.icons();});
  ui.update({people:peopleFor()});
  renderChoices(choices);draftState();syncVariantControls();
  phone=window.installNarrativePhone?window.installNarrativePhone(root):null;
  root.addEventListener('narrative:phone-open',()=>{closePanels();closeSheet(false);});
  q('[data-request-undo]').disabled=true;icons();
})();

(function(){
  const review=document.getElementById('nr-reference');if(!review)return;
  const root=document.getElementById('nr-app'),frame=review.querySelector('[data-viewport-frame]'),width=review.querySelector('[data-mobile-width]'),output=review.querySelector('[data-viewport-size]');
  function measure(){const rect=root.getBoundingClientRect();output.textContent=Math.round(rect.width)+' × '+Math.round(rect.height);}
  review.querySelectorAll('[data-viewport]').forEach(button=>button.addEventListener('click',()=>{
    const mode=button.dataset.viewport;frame.dataset.viewportFrame=mode;frame.style.width=mode==='mobile'?width.value+'px':'';width.hidden=mode!=='mobile';
    review.querySelectorAll('[data-viewport]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
    root.dispatchEvent(new CustomEvent('nr:viewport-change'));measure();
  }));
  width.addEventListener('change',()=>{frame.style.width=width.value+'px';root.dispatchEvent(new CustomEvent('nr:viewport-change'));measure();});
  review.querySelector('[data-reference-reset]').addEventListener('click',()=>root.__nrUI.reset());
  review.querySelectorAll('button,select').forEach(b=>b.classList.add('cursor-interaction'));
  if(window.ResizeObserver)new ResizeObserver(measure).observe(root);measure();
})();

"""Build offline product and review pages plus the inline review fragment."""
from pathlib import Path
import argparse
import base64

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'src'
DIST = ROOT / 'dist'
CSS = ['core.css', 'management.css', 'shell-features.css', 'phone.css']
JS = ['ui-shell.js', 'phone.js', 'main.js', 'management.js', 'shell-features.js']

def build(inline_path=None):
    DIST.mkdir(exist_ok=True)
    font_rules = []
    for subset, unicode_range in [
        ('cyrillic','U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116'),
        ('latin','U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD'),
    ]:
        encoded = base64.b64encode((ROOT / 'assets' / f'inter-{subset}.woff2').read_bytes()).decode()
        font_rules.append("@font-face{font-family:Inter;font-style:normal;font-weight:100 900;font-display:swap;src:url(data:font/woff2;base64,"+encoded+") format('woff2');unicode-range:"+unicode_range+"}")
    styles = '\n'.join(font_rules + [(SRC / name).read_text() for name in CSS])
    app = (SRC / 'base.html').read_text().replace('<!-- PHONE_MARKUP -->',(SRC/'phone-markup.html').read_text())
    scripts = '\n'.join((SRC/name).read_text() for name in JS)
    scripts += "\n{ const root=document.getElementById('nr-app');window.installNarrativeManagement(root,root.__nrUI);window.installNarrativeShellFeatures(root,root.__nrUI);root.__nrUI.icons(); }\n"
    icons = (ROOT/'assets/lucide.min.js').read_text().replace('//# sourceMappingURL=lucide.min.js.map','')
    template = (SRC/'document.html').read_text()
    review_markup = (SRC/'review.html').read_text().replace('<!-- APPLICATION -->',app)
    review_styles = (SRC/'review.css').read_text()
    review_scripts = (SRC/'review.js').read_text()
    for filename, content, css, js, class_name in [
        ('index.html',app,styles,scripts,''),
        ('review.html',review_markup,styles+'\n'+review_styles,scripts+'\n'+review_scripts,'review-page')
    ]:
        result=template.replace('/* STYLES */',css).replace('<!-- CONTENT -->',content).replace('/* ICON_LIBRARY */',icons).replace('/* APPLICATION_SCRIPTS */',js).replace('DOCUMENT_CLASS',class_name)
        (DIST/filename).write_text(result)
        print(filename, len(result.encode()),'bytes')
    if inline_path:
        fragment='<style>\n'+styles+'\n'+review_styles+'\n</style>\n'+review_markup+'\n<script>\n'+scripts+'\n'+review_scripts+'\n</script>\n'
        if len(fragment.encode()) >= 1_000_000: raise ValueError('Inline preview exceeds 1 MB')
        Path(inline_path).write_text(fragment)
        print('Inline',len(fragment.encode()),'bytes')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--inline');args=parser.parse_args();build(args.inline)
